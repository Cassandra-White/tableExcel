# ============================================================================
# Fichier  : 00-Config.ps1
# Description : Configuration centrale - dot-source par les scripts 01 02 03
#               Toute modification de la structure AD se fait ICI uniquement.
# ============================================================================

# ============================================================================
# PARAMETRES GENERAUX
# ============================================================================

$OrgName           = "BillU"
$DomainEmailSuffix = "billu.com"    # Vide = utilise le DNSRoot du domaine AD
$LogBaseDir        = "C:\Logs"
$SocietePrincipale = "BillU"        # Filtre sur la colonne "Societe" du CSV
$CSVDelimiter      = ";"

# ============================================================================
# OU ORDINATEURS - TOUJOURS PLATE (pas de sous-OUs)
# ============================================================================

$OuPCs = "Ordinateurs"

# ============================================================================
# OUs PRINCIPALES SUPPLEMENTAIRES
# ============================================================================

$MainOUsExtra = @(
    @{ OUName = "Comptes-Admin";   Description = "Comptes administrateurs a privileges eleves" },
    @{ OUName = "Comptes-Service"; Description = "Comptes de service pour applications" }
)

# ============================================================================
# DEPARTEMENTS ET LEURS SERVICES
# ============================================================================
# CSVName  : valeur EXACTE de la colonne "Departement" dans le CSV (avec accents)
# OUName   : nom ASCII utilise dans Active Directory (sans accents ni caracteres speciaux)
# GroupCode: prefixe court MAJUSCULES pour les noms de groupes AD
#
# Pour les Services :
#   CSVName : valeur exacte de la colonne "Service" dans le CSV
#   OUName  : nom ASCII de la sous-OU creee dans AD
#
# Services = @() -> pas de sous-OU, utilisateurs places directement dans l'OU dept

$Departements = @(

    @{
        CSVName         = "Direction"
        OUName          = "Direction"
        Description     = "Direction generale et comite executif"
        GroupCode       = "DIRECTION"
        HasAdminGroup   = $true
        HasDistribGroup = $true
        Services        = @()
    },

    @{
        CSVName         = "Developpement logiciel"
        OUName          = "Dev-Logiciel"
        Description     = "Equipe de developpement logiciel"
        GroupCode       = "DEV"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            @{ CSVName = "analyse et conception";  OUName = "Analyse-Conception"   },
            @{ CSVName = "Developpement";          OUName = "Developpement"         },
            @{ CSVName = "Recherche et Prototype"; OUName = "Recherche-Prototype"   },
            @{ CSVName = "Tests et qualite";       OUName = "Tests-Qualite"         }
        )
    },

    @{
        CSVName         = "DSI"
        OUName          = "DSI"
        Description     = "Direction des Systemes d Information"
        GroupCode       = "DSI"
        HasAdminGroup   = $true
        HasDistribGroup = $true
        Services        = @(
            @{ CSVName = "Administration Systemes et Reseaux"; OUName = "Admin-Systemes-Reseaux" },
            @{ CSVName = "Developpement et Integration";       OUName = "Dev-Integration"        },
            @{ CSVName = "Exploitation";                       OUName = "Exploitation"            },
            @{ CSVName = "Support";                            OUName = "Support"                 }
        )
    },

    @{
        CSVName         = "Service Commercial"
        OUName          = "Commercial"
        Description     = "Service commercial ventes achats et service client"
        GroupCode       = "COMMERCIAL"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            @{ CSVName = "ADV";            OUName = "ADV"            },
            @{ CSVName = "B2B";            OUName = "B2B"            },
            @{ CSVName = "Service achat";  OUName = "Service-Achat"  },
            @{ CSVName = "Service Client"; OUName = "Service-Client" }
        )
    },

    @{
        CSVName         = "Communication et Relations publiques"
        OUName          = "Communication"
        Description     = "Communication relations medias et gestion des marques"
        GroupCode       = "COMM"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            @{ CSVName = "Communication interne"; OUName = "Communication-Interne" },
            @{ CSVName = "Gestion des marques";   OUName = "Gestion-Marques"       },
            @{ CSVName = "Relation Medias";       OUName = "Relation-Medias"       }
        )
    },

    @{
        CSVName         = "Departement Juridique"
        OUName          = "Juridique"
        Description     = "Service juridique conformite et propriete intellectuelle"
        GroupCode       = "JURIDIQUE"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            @{ CSVName = "Droit des societes";                   OUName = "Droit-Societes"          },
            @{ CSVName = "Propriete intellectuelle";             OUName = "Propriete-Intellectuelle" },
            @{ CSVName = "Protection des donnees et conformite"; OUName = "Protection-Donnees"       }
        )
    },

    @{
        CSVName         = "Finance et Comptabilite"
        OUName          = "Finance"
        Description     = "Finance comptabilite et controle de gestion"
        GroupCode       = "FINANCE"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            @{ CSVName = "Finance";              OUName = "Finance"      },
            @{ CSVName = "Fiscalite";            OUName = "Fiscalite"    },
            @{ CSVName = "Service Comptabilite"; OUName = "Comptabilite" }
        )
    },

    @{
        CSVName         = "QHSE"
        OUName          = "QHSE"
        Description     = "Qualite Hygiene Securite Environnement"
        GroupCode       = "QHSE"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            @{ CSVName = "Certification";            OUName = "Certification"          },
            @{ CSVName = "Controle Qualite";         OUName = "Controle-Qualite"       },
            @{ CSVName = "Gestion environnementale"; OUName = "Gestion-Environnement"  }
        )
    },

    @{
        CSVName         = "Service recrutement"
        OUName          = "Recrutement"
        Description     = "Service recrutement et ressources humaines"
        GroupCode       = "RH"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @()
    }
)

# ============================================================================
# SOUS-OUs DE L'OU GROUPES
# ============================================================================

$GroupSubOUs = @(
    @{ OUName = "Groupes-Departements"; Description = "Groupes de securite par departement"             },
    @{ OUName = "Groupes-Fonctionnels"; Description = "Groupes fonctionnels VPN WiFi applications"      },
    @{ OUName = "Groupes-Securite";     Description = "Groupes de securite pour acces aux ressources"   }
)

# ============================================================================
# GROUPES FONCTIONNELS
# ============================================================================

$GroupesFonctionnels = @(
    @{ Name = "GG_VPN_Access";        Description = "Acces VPN connexion a distance";        Scope = "Global";    Category = "Security"     },
    @{ Name = "GG_WiFi_Access";       Description = "Acces WiFi Corporate 802.1X WPA3";      Scope = "Global";    Category = "Security"     },
    @{ Name = "GG_PRINT_RDC";         Description = "Acces imprimantes Rez-de-Chaussee";     Scope = "Global";    Category = "Security"     },
    @{ Name = "GG_PRINT_ETG1";        Description = "Acces imprimantes Etage 1";             Scope = "Global";    Category = "Security"     },
    @{ Name = "GG_PRINT_ETG2";        Description = "Acces imprimantes Etage 2";             Scope = "Global";    Category = "Security"     },
    @{ Name = "GG_APP_GLPI_Users";    Description = "Utilisateurs GLPI ticketing";           Scope = "Global";    Category = "Security"     },
    @{ Name = "GG_APP_GLPI_Admins";   Description = "Administrateurs GLPI";                  Scope = "Global";    Category = "Security"     },
    @{ Name = "GG_APP_Zabbix_Users";  Description = "Utilisateurs Zabbix monitoring";        Scope = "Global";    Category = "Security"     },
    @{ Name = "GG_APP_Zabbix_Admins"; Description = "Administrateurs Zabbix";                Scope = "Global";    Category = "Security"     },
    @{ Name = "GG_ALL_Employees";     Description = "Tous les employes de $OrgName";         Scope = "Universal"; Category = "Security"     },
    @{ Name = "GD_ALL_Staff";         Description = "Liste distribution tous les employes";  Scope = "Universal"; Category = "Distribution" }
)

# ============================================================================
# GROUPES PARTAGES RESEAU  (GG_{Code}_{Permission})
# ============================================================================

$PartagesConfig = @(
    @{ DeptCode = "FINANCE";    Permissions = @("RO", "RW", "FULL") },
    @{ DeptCode = "JURIDIQUE";  Permissions = @("RO", "RW", "FULL") },
    @{ DeptCode = "DIRECTION";  Permissions = @("RO", "RW", "FULL") },
    @{ DeptCode = "DEV";        Permissions = @("RW")               },
    @{ DeptCode = "COMMERCIAL"; Permissions = @("RW")               },
    @{ DeptCode = "COMMUN";     Permissions = @("RW")               }
)

# ============================================================================
# FIN DE LA CONFIGURATION
# ============================================================================
