# ============================================================================
# Script      : 01-Create-OU-Structure.ps1
# Description : Creation de l'arborescence des OUs
# Prerequis   : 00-Config.ps1 dans le meme dossier
# ============================================================================

<#
.SYNOPSIS
    Cree toute l'arborescence des OUs a partir de 00-Config.ps1.

.DESCRIPTION
    Structure creee :
      OU=Utilisateurs
        OU=<Dept.OUName>             (un par departement)
          OU=<Svc.OUName>            (une par service si Dept.Services n'est pas vide)
      OU=Ordinateurs                 (plate - aucune sous-OU)
      OU=Groupes
        OU=<GroupSubOU.OUName>
      OU=<MainOUsExtra.OUName>       (ex : Comptes-Admin, Comptes-Service)

    Tous les noms d'OUs sont en ASCII pur (definis via OUName dans 00-Config.ps1).

.PARAMETER LogFile
    Chemin du fichier de log (defaut : $LogBaseDir\OU-Creation.log)

.PARAMETER WhatIf
    Mode simulation - aucune OU creee

.EXAMPLE
    .\01-Create-OU-Structure.ps1
    .\01-Create-OU-Structure.ps1 -WhatIf
    .\01-Create-OU-Structure.ps1 -LogFile "D:\Logs\ou.log"
#>

[CmdletBinding()]
param(
    [string]$LogFile = "",
    [switch]$WhatIf
)

# ============================================================================
# CHARGEMENT CONFIG
# ============================================================================

$ConfigFile = Join-Path $PSScriptRoot "00-Config.ps1"
if (-not (Test-Path $ConfigFile)) { Write-Error "00-Config.ps1 introuvable : $ConfigFile"; exit 1 }
. $ConfigFile

if (-not $LogFile) { $LogFile = Join-Path $LogBaseDir "OU-Creation.log" }

# ============================================================================
# INITIALISATION
# ============================================================================

$LogDir = Split-Path $LogFile -Parent
if (-not (Test-Path $LogDir)) { New-Item -Path $LogDir -ItemType Directory -Force | Out-Null }

try { Import-Module ActiveDirectory -ErrorAction Stop }
catch { Write-Error "Module ActiveDirectory non disponible. Installez RSAT."; exit 1 }

$DomainDN   = (Get-ADDomain).DistinguishedName
$DomainName = (Get-ADDomain).DNSRoot

$Script:TotalOUs = 0; $Script:CreatedOUs = 0
$Script:ExistOUs = 0; $Script:ErrorOUs   = 0

# ============================================================================
# FONCTIONS
# ============================================================================

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','SUCCESS','WARNING','ERROR')]
        [string]$Level = 'INFO'
    )
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogFile -Value "[$ts] [$Level] $Message"
    switch ($Level) {
        'SUCCESS' { Write-Host $Message -ForegroundColor Green  }
        'WARNING' { Write-Host $Message -ForegroundColor Yellow }
        'ERROR'   { Write-Host $Message -ForegroundColor Red    }
        default   { Write-Host $Message -ForegroundColor White  }
    }
}

function New-OU {
    param(
        [string]$OUName,
        [string]$Path,
        [string]$Description = "",
        [string]$Indent = "  "
    )
    $Script:TotalOUs++
    $OUDN = "OU=$OUName,$Path"

    try {
        if (Get-ADOrganizationalUnit -Filter "DistinguishedName -eq '$OUDN'" -ErrorAction SilentlyContinue) {
            Write-Log "${Indent}(existe)  OU=$OUName" -Level WARNING
            $Script:ExistOUs++; return
        }
        if ($WhatIf) {
            Write-Log "${Indent}[SIM] OU=$OUName  dans  $Path" -Level INFO
            $Script:CreatedOUs++; return
        }
        New-ADOrganizationalUnit -Name $OUName -Path $Path -Description $Description `
            -ProtectedFromAccidentalDeletion $true | Out-Null
        Write-Log "${Indent}+ OU=$OUName" -Level SUCCESS
        $Script:CreatedOUs++
    }
    catch {
        Write-Log "${Indent}ERREUR  OU=$OUName : $($_.Exception.Message)" -Level ERROR
        $Script:ErrorOUs++
    }
}

# ============================================================================
# SCRIPT PRINCIPAL
# ============================================================================

Write-Log "========================================" -Level INFO
Write-Log "DEBUT - Creation OUs [$OrgName]"         -Level INFO
Write-Log "Domaine : $DomainName"                   -Level INFO
Write-Log "DN      : $DomainDN"                     -Level INFO
if ($WhatIf) { Write-Log "!!! MODE SIMULATION !!!" -Level WARNING }
Write-Log "========================================" -Level INFO
Write-Host ""

# -----------------------------------------------------------------------
# ETAPE 1 : OUs PRINCIPALES
# -----------------------------------------------------------------------

Write-Log "--- OUs Principales ---" -Level INFO

New-OU -OUName "Utilisateurs" -Path $DomainDN -Description "Comptes utilisateurs de $OrgName"
New-OU -OUName $OuPCs         -Path $DomainDN -Description "Ordinateurs $OrgName - OU plate sans sous-OUs"
New-OU -OUName "Groupes"      -Path $DomainDN -Description "Groupes AD de $OrgName"

foreach ($OU in $MainOUsExtra) {
    New-OU -OUName $OU.OUName -Path $DomainDN -Description $OU.Description
}

Write-Host ""

# -----------------------------------------------------------------------
# ETAPE 2 : DEPARTEMENTS ET SERVICES
# -----------------------------------------------------------------------

Write-Log "--- Departements et Services ---" -Level INFO
Write-Host ""

$UtilOU = "OU=Utilisateurs,$DomainDN"

foreach ($Dept in $Departements) {
    Write-Log "  [Dept] $($Dept.OUName)  (CSV : $($Dept.CSVName))" -Level INFO

    New-OU -OUName $Dept.OUName -Path $UtilOU -Description $Dept.Description -Indent "    "

    if ($Dept.Services.Count -gt 0) {
        $DeptOU = "OU=$($Dept.OUName),$UtilOU"
        foreach ($Svc in $Dept.Services) {
            New-OU -OUName $Svc.OUName -Path $DeptOU `
                   -Description "Service $($Svc.OUName) - $($Dept.OUName)" `
                   -Indent "      "
        }
    }
    else {
        Write-Log "      (pas de sous-OU service)" -Level INFO
    }
    Write-Host ""
}

# -----------------------------------------------------------------------
# ETAPE 3 : ORDINATEURS - OU PLATE
# -----------------------------------------------------------------------

Write-Log "--- OU Ordinateurs ---" -Level INFO
Write-Log "  Tous les PCs dans : OU=$OuPCs,$DomainDN  (aucune sous-OU)" -Level INFO
Write-Host ""

# -----------------------------------------------------------------------
# ETAPE 4 : SOUS-OUs GROUPES
# -----------------------------------------------------------------------

Write-Log "--- Sous-OUs Groupes ---" -Level INFO

$GrpOU = "OU=Groupes,$DomainDN"
foreach ($SubOU in $GroupSubOUs) {
    New-OU -OUName $SubOU.OUName -Path $GrpOU -Description $SubOU.Description
}

Write-Host ""

# ============================================================================
# RECAPITULATIF
# ============================================================================

Write-Log "========================================" -Level INFO
Write-Log "RECAPITULATIF"                            -Level INFO
Write-Log "  Total traite  : $Script:TotalOUs"       -Level INFO
Write-Log "  Crees         : $Script:CreatedOUs"     -Level SUCCESS
Write-Log "  Existants     : $Script:ExistOUs"       -Level WARNING
Write-Log "  Erreurs       : $Script:ErrorOUs"       -Level ERROR
Write-Log "========================================" -Level INFO
Write-Host ""

if (-not $WhatIf) {
    $ExportPath = Join-Path $LogBaseDir "OU-Structure-$(Get-Date -Format 'yyyyMMdd-HHmmss').csv"
    Get-ADOrganizationalUnit -Filter * |
        Select-Object Name, DistinguishedName |
        Sort-Object DistinguishedName |
        Export-Csv -Path $ExportPath -NoTypeInformation -Encoding UTF8
    Write-Log "Export structure : $ExportPath" -Level SUCCESS
}

Write-Log "FIN - Creation OUs" -Level INFO
