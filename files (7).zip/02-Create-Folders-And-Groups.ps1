#Requires -RunAsAdministrator
# 02-Create-Folders-And-Groups.ps1 -- BillU Sprint 5
# CORRECTION : utilise les SIDs (invariants selon la langue Windows)
# car "BUILTIN\Administrators" = "BUILTIN\Administrateurs" sur Windows FR
# $script: prefix pour que les variables soient accessibles dans la fonction

. ".\00-Config.ps1"

$DomInfo      = Get-ADDomain -Credential $ADCredential
$DN           = $DomInfo.DistinguishedName
$SiteDN       = "OU=$SiteOU,OU=$CountryOU,OU=$RootOU,$DN"
$OuSecu       = "OU=Groupes-Securite,OU=Groupes,$SiteDN"
$script:Base  = "D:\Partages"
$script:NB    = $DomInfo.NetBIOSName   # BILLU

# SID Domain Admins (invariant -- pas de probleme de langue)
$script:DomAdminsSID = (Get-ADGroup "Domain Admins" -Credential $ADCredential).SID

# ======================================================
# Helper : ACL propre avec admins en Full en PREMIER
# SID S-1-5-32-544 = BUILTIN\Administrators (toutes langues)
# SID S-1-5-18     = NT AUTHORITY\SYSTEM
# ======================================================
function Get-AdminACL {
    param([System.Security.AccessControl.FileSystemAccessRule[]]$Extra = @())

    $acl  = New-Object System.Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)   # couper heritage

    $inh  = [System.Security.AccessControl.InheritanceFlags]"ContainerInherit,ObjectInherit"
    $prop = [System.Security.AccessControl.PropagationFlags]::None
    $alw  = [System.Security.AccessControl.AccessControlType]::Allow
    $full = [System.Security.AccessControl.FileSystemRights]::FullControl

    # --- ADMINS EN PREMIER via SID (independant de la langue Windows) ---
    $adminSIDs = @(
        [System.Security.Principal.SecurityIdentifier]"S-1-5-32-544",  # Administrators/Administrateurs
        [System.Security.Principal.SecurityIdentifier]"S-1-5-18",      # SYSTEM
        $script:DomAdminsSID                                            # Domain Admins billu.local
    )
    foreach ($sid in $adminSIDs) {
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule(
            $sid, $full, $inh, $prop, $alw)))
    }

    # --- Regles utilisateurs/groupes supplementaires ---
    foreach ($r in $Extra) { $acl.AddAccessRule($r) }

    return $acl
}

$inh  = [System.Security.AccessControl.InheritanceFlags]"ContainerInherit,ObjectInherit"
$prop = [System.Security.AccessControl.PropagationFlags]::None
$alw  = [System.Security.AccessControl.AccessControlType]::Allow
$mod  = [System.Security.AccessControl.FileSystemRights]::Modify

# ---- 1. Arborescence racine -- Admins Only ----
foreach ($d in @("$script:Base\Homes","$script:Base\Services","$script:Base\Departements")) {
    New-Item $d -ItemType Directory -Force | Out-Null
    Set-Acl $d (Get-AdminACL)
    Write-Host "[OK] Racine : $d (Admins Only)"
}

# ---- 2. Dossiers de service J: ----
Write-Host ""
Write-Host "=== Groupes et dossiers de service ==="
foreach ($Dept in $Departements) {
    foreach ($Svc in $Dept.Services) {
        $grp = "GG_SVC_$($Svc.OUName)"
        $dir = "$script:Base\Services\$($Svc.OUName)"

        # Creer le groupe si absent
        if (-not (Get-ADGroup -Filter "Name -eq '$grp'" -Credential $ADCredential -EA SilentlyContinue)) {
            New-ADGroup -Name $grp -GroupScope Global -GroupCategory Security `
                -Path $OuSecu -Description "Acces J: $($Svc.OUName)" -Credential $ADCredential
            Write-Host "  [NEW] $grp"
        } else { Write-Host "  [OK] $grp existe" }

        New-Item $dir -ItemType Directory -Force | Out-Null

        # Recuperer le SID du groupe AD (invariant)
        $grpSID = (Get-ADGroup $grp -Credential $ADCredential).SID
        $r = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $grpSID, $mod, $inh, $prop, $alw)
        Set-Acl $dir (Get-AdminACL -Extra @($r))
        Write-Host "  [ACL] $dir -> Admins=Full | $grp=Modify"
    }
}

# ---- 3. Dossiers departement K: ----
Write-Host ""
Write-Host "=== Dossiers de departement ==="
$deptMap = @{
    "Direction"    = "GG_DIRECTION_Users"; "Dev-Logiciel" = "GG_DEV_Users"
    "DSI"          = "GG_DSI_Users";       "Commercial"   = "GG_COMMERCIAL_Users"
    "Communication"= "GG_COMM_Users";      "Juridique"    = "GG_JURIDIQUE_Users"
    "Finance"      = "GG_FINANCE_Users";   "QHSE"         = "GG_QHSE_Users"
    "Recrutement"  = "GG_RH_Users"
}
foreach ($dept in $deptMap.Keys) {
    $dir = "$script:Base\Departements\$dept"
    New-Item $dir -ItemType Directory -Force | Out-Null
    $grpSID = (Get-ADGroup $deptMap[$dept] -Credential $ADCredential).SID
    $r = New-Object System.Security.AccessControl.FileSystemAccessRule(
        $grpSID, $mod, $inh, $prop, $alw)
    Set-Acl $dir (Get-AdminACL -Extra @($r))
    Write-Host "  [OK] $dept -> Admins=Full | $($deptMap[$dept])=Modify"
}

Write-Host ""
Write-Host "=== Verification rapide des ACL ==="
foreach ($d in Get-ChildItem $script:Base -Recurse -Directory) {
    $acl = Get-Acl $d.FullName
    $adminOK = $acl.Access | Where-Object {
        $_.IdentityReference -match "544|SYSTEM|Domain Admins" -and
        $_.FileSystemRights  -match "FullControl"
    }
    $status = if ($adminOK) { "OK" } else { "!!! ADMINS MANQUANTS" }
    Write-Host "  [$status] $($d.FullName)"
}

Write-Host ""
Write-Host "=== Script 02 termine -- lancer 03-Create-UserHomeFolders.ps1 ==="
