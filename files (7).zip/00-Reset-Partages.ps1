#Requires -RunAsAdministrator
# 00-Reset-Partages.ps1 -- BillU Sprint 5
# Annule tout ce que le script 02 a fait :
#   1. Supprime les partages SMB (Homes, Services, Departements)
#   2. Supprime D:\Partages et tout son contenu
#   3. Supprime les groupes GG_SVC_* crees
#   4. Vide les membres des groupes GG_SVC_* si deja peuples (script 04)
#
# ATTENTION : les donnees dans D:\Partages sont perdues definitivement
#             Ne lancer qu en lab / phase de test

. ".\00-Config.ps1"

$DomInfo = Get-ADDomain -Credential $ADCredential
$SiteDN  = "OU=$SiteOU,OU=$CountryOU,OU=$RootOU,$($DomInfo.DistinguishedName)"
$Base    = "D:\Partages"

Write-Host "=== RESET -- annulation du script 02 ===" -ForegroundColor Yellow
Write-Host "Cible : $Base | Domaine : $($DomInfo.DNSRoot)"
Write-Host ""

# --------------------------------------------------------
# 1. Supprimer les partages SMB
# --------------------------------------------------------
Write-Host "--- Suppression des partages SMB ---"
foreach ($name in @("Homes","Services","Departements")) {
    if (Get-SmbShare -Name $name -EA SilentlyContinue) {
        Remove-SmbShare -Name $name -Force
        Write-Host "  [OK] Partage $name supprime"
    } else {
        Write-Host "  [--] Partage $name absent"
    }
}

# --------------------------------------------------------
# 2. Reprendre le controle de D:\Partages avant suppression
#    (si les ACL sont cassees, takeown + icacls pour forcer)
# --------------------------------------------------------
Write-Host ""
Write-Host "--- Reprise du controle NTFS ---"
if (Test-Path $Base) {
    # takeown : prendre possession de tous les sous-dossiers
    & takeown /F "$Base" /R /D O /A 2>$null
    # icacls : donner FullControl aux Administrateurs sur tout l arbre
    & icacls "$Base" /grant "Administrateurs:(OI)(CI)F" /T /C /Q 2>$null
    & icacls "$Base" /grant "Administrators:(OI)(CI)F"  /T /C /Q 2>$null
    & icacls "$Base" /grant "SYSTEM:(OI)(CI)F"          /T /C /Q 2>$null
    Write-Host "  [OK] FullControl restaure sur $Base"
} else {
    Write-Host "  [--] $Base absent -- rien a reprendre"
}

# --------------------------------------------------------
# 3. Supprimer D:\Partages
# --------------------------------------------------------
Write-Host ""
Write-Host "--- Suppression de $Base ---"
if (Test-Path $Base) {
    Remove-Item $Base -Recurse -Force -ErrorAction SilentlyContinue
    if (-not (Test-Path $Base)) {
        Write-Host "  [OK] $Base supprime"
    } else {
        Write-Host "  [ERR] Suppression incomplete -- fichiers verrouilles ?" -ForegroundColor Red
        Get-ChildItem $Base -Recurse | Where-Object { -not $_.PSIsContainer } |
            Select-Object FullName | Format-Table
    }
} else {
    Write-Host "  [--] $Base absent"
}

# --------------------------------------------------------
# 4. Supprimer les groupes GG_SVC_*
# --------------------------------------------------------
Write-Host ""
Write-Host "--- Suppression des groupes GG_SVC_ ---"
$grpsToDelete = Get-ADGroup -Filter { Name -like "GG_SVC_*" } `
    -SearchBase "OU=Groupes-Securite,OU=Groupes,$SiteDN" `
    -Credential $ADCredential -EA SilentlyContinue

if ($grpsToDelete) {
    foreach ($g in $grpsToDelete) {
        Remove-ADGroup -Identity $g.DistinguishedName -Credential $ADCredential -Confirm:$false
        Write-Host "  [OK] $($g.Name) supprime"
    }
} else {
    Write-Host "  [--] Aucun groupe GG_SVC_ trouve"
}

# --------------------------------------------------------
# 5. Rapport final
# --------------------------------------------------------
Write-Host ""
Write-Host "=== RESET TERMINE ===" -ForegroundColor Green
Write-Host "Vous pouvez relancer 02-Create-Folders-And-Groups.ps1 proprement."
Write-Host ""
Write-Host "Etat apres reset :"
Write-Host "  D:\Partages existe    : $(Test-Path $Base)"
Write-Host "  Partages SMB Homes    : $([bool](Get-SmbShare -Name 'Homes'    -EA SilentlyContinue))"
Write-Host "  Partages SMB Services : $([bool](Get-SmbShare -Name 'Services' -EA SilentlyContinue))"
Write-Host "  Groupes GG_SVC_ restants : $((Get-ADGroup -Filter {Name -like 'GG_SVC_*'} -Credential $ADCredential -EA SilentlyContinue | Measure-Object).Count)"
