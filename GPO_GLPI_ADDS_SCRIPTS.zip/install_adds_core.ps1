#Requires -RunAsAdministrator
<#
.SYNOPSIS  Installation AD-DS sur Windows Server Core — BillU Groupe 1
.NOTES     Exécuter LOCALEMENT sur le WS Core (via SSH ou session console)
           Usage : .\install_adds_core.ps1
                   .\install_adds_core.ps1 -ConfigFile "C:\adds.conf"
           
           PRÉREQUIS :
             - Windows Server Core 2022 déjà installé
             - Connexion réseau vers DC1 (172.16.10.1) opérationnelle
             - Compte Administrateur du domaine disponible
#>

[CmdletBinding()]
param(
    [string]$ConfigFile = "$PSScriptRoot\adds.conf"
)

# ── HELPERS ───────────────────────────────────────────────────────────────────
function Write-Step($M,$C="Cyan") { Write-Host "`n[$([datetime]::Now.ToString('HH:mm:ss'))] $M" -ForegroundColor $C }
function Write-OK($M)   { Write-Host "  [OK]  $M" -ForegroundColor Green  }
function Write-ERR($M)  { Write-Host "  [!!]  $M" -ForegroundColor Red    }
function Write-INFO($M) { Write-Host "  [i]   $M" -ForegroundColor DarkCyan }
function Write-WARN($M) { Write-Host "  [~~]  $M" -ForegroundColor Yellow  }

# ── CHARGEMENT DE LA CONFIGURATION ────────────────────────────────────────────
Write-Step "Chargement de la configuration" "White"

if (-not (Test-Path $ConfigFile)) {
    Write-ERR "Fichier de config introuvable : $ConfigFile"
    Write-ERR "Créer adds.conf à côté du script"
    exit 1
}

# Parser le fichier .conf (format clé = valeur)
$config = @{}
Get-Content $ConfigFile | Where-Object { $_ -notmatch '^\s*#' -and $_ -match '=' } | ForEach-Object {
    $parts = $_ -split '=', 2
    $key   = $parts[0].Trim()
    $value = $parts[1].Trim().Trim('"').Trim("'")
    $config[$key] = $value
}

# Vérifier les clés obligatoires
$required = @("ServerName","StaticIP","SubnetMask","Gateway","DNSPrimary","DomainName","SafeModePassword","AdminUser","AdminDomain")
foreach ($key in $required) {
    if (-not $config.ContainsKey($key)) { Write-ERR "Clé manquante dans adds.conf : $key"; exit 1 }
}
Write-OK "Configuration chargée : $ConfigFile"
Write-INFO "Serveur   : $($config.ServerName)"
Write-INFO "Domaine   : $($config.DomainName)"
Write-INFO "IP cible  : $($config.StaticIP)"
Write-INFO "DNS prim  : $($config.DNSPrimary)"

# ── ÉTAPE 1 : RENOMMER LE SERVEUR ─────────────────────────────────────────────
Write-Step "Etape 1 - Renommer le serveur si nécessaire"

$currentName = $env:COMPUTERNAME
if ($currentName -ne $config.ServerName) {
    Write-WARN "Nom actuel : $currentName → Nouveau : $($config.ServerName)"
    Rename-Computer -NewName $config.ServerName -Force
    Write-OK "Serveur renommé → $($config.ServerName) (redémarrage nécessaire)"
    Write-WARN "Le script reprendra après redémarrage — relancer après restart"
    # Créer une tâche planifiée pour relancer après reboot
    $scriptPath = $MyInvocation.MyCommand.Path
    $action     = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "-ExecutionPolicy Bypass -File `"$scriptPath`" -ConfigFile `"$ConfigFile`""
    $trigger    = New-ScheduledTaskTrigger -AtStartup
    $principal  = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
    Register-ScheduledTask -TaskName "BillU_ADDS_Install" -Action $action -Trigger $trigger -Principal $principal -Force | Out-Null
    Write-INFO "Tâche planifiée créée : BillU_ADDS_Install (se relancera au démarrage)"
    Restart-Computer -Force
    exit 0
} else {
    Write-OK "Nom du serveur déjà correct : $currentName"
}

# ── ÉTAPE 2 : CONFIGURER L'IP FIXE ────────────────────────────────────────────
Write-Step "Etape 2 - Configuration IP fixe"

$adapter = Get-NetAdapter | Where-Object { $_.Status -eq "Up" } | Select-Object -First 1
if (-not $adapter) { Write-ERR "Aucune carte réseau active trouvée"; exit 1 }

Write-INFO "Interface réseau : $($adapter.Name)"

# Retirer les configs IP existantes
Remove-NetIPAddress -InterfaceAlias $adapter.Name -Confirm:$false -EA SilentlyContinue
Remove-NetRoute     -InterfaceAlias $adapter.Name -Confirm:$false -EA SilentlyContinue

# Configurer IP fixe
$prefix = (ConvertTo-Prefix $config.SubnetMask)
New-NetIPAddress -InterfaceAlias $adapter.Name `
    -IPAddress    $config.StaticIP `
    -PrefixLength $prefix `
    -DefaultGateway $config.Gateway | Out-Null

# Configurer DNS
Set-DnsClientServerAddress -InterfaceAlias $adapter.Name `
    -ServerAddresses @($config.DNSPrimary, $config.DNSSecondary)

Write-OK "IP fixe configurée : $($config.StaticIP)/$prefix — GW : $($config.Gateway)"
Write-OK "DNS : $($config.DNSPrimary) (primaire) / $($config.DNSSecondary) (secondaire)"

# Tester la connectivité vers DC1
Write-INFO "Test de connexion vers DC1 ($($config.DNSPrimary))..."
if (Test-Connection -ComputerName $config.DNSPrimary -Count 2 -Quiet) {
    Write-OK "DC1 ($($config.DNSPrimary)) accessible"
} else {
    Write-ERR "DC1 ($($config.DNSPrimary)) inaccessible — vérifier le réseau Proxmox"
    Write-WARN "Continuer quand même ? (O/N)"
    $rep = Read-Host
    if ($rep -ne "O") { exit 1 }
}

# ── ÉTAPE 3 : INSTALLER LE RÔLE AD-DS ─────────────────────────────────────────
Write-Step "Etape 3 - Installation du rôle AD-DS (+ DNS)"

$features = @("AD-Domain-Services", "DNS", "RSAT-ADDS", "RSAT-ADCS")
foreach ($feat in $features) {
    if (-not (Get-WindowsFeature $feat).Installed) {
        Write-INFO "Installation de $feat..."
        Install-WindowsFeature -Name $feat -IncludeManagementTools | Out-Null
        Write-OK "$feat installé"
    } else {
        Write-OK "$feat déjà installé"
    }
}

# ── ÉTAPE 4 : PROMOUVOIR EN DC SECONDAIRE ────────────────────────────────────
Write-Step "Etape 4 - Promotion en contrôleur de domaine secondaire"

Import-Module ADDSDeployment -EA Stop

# Demander le mot de passe admin domaine de façon sécurisée
Write-INFO "Entrer le mot de passe de $($config.AdminDomain)\$($config.AdminUser) :"
$domainCred = Get-Credential -UserName "$($config.AdminDomain)\$($config.AdminUser)" `
    -Message "Mot de passe administrateur du domaine $($config.DomainName)"

# Convertir le SafeModePassword en SecureString
$safeModePass = ConvertTo-SecureString $config.SafeModePassword -AsPlainText -Force

Write-INFO "Lancement de la promotion DC — cela peut prendre 5 à 10 minutes..."
Write-WARN "Le serveur redémarrera automatiquement à la fin"

$installParams = @{
    DomainName                    = $config.DomainName
    Credential                    = $domainCred
    SafeModeAdministratorPassword = $safeModePass
    SiteName                      = $config.SiteName
    DatabasePath                  = $config.DatabasePath
    LogPath                       = $config.LogPath
    SysvolPath                    = $config.SysvolPath
    ReplicationSourceDC           = $config.ReplicationSourceDC
    NoGlobalCatalog               = $false
    InstallDns                    = ($config.InstallDNS -eq "true")
    Force                         = $true
}

# Lancement de la promotion
Install-ADDSDomainController @installParams

# Note : après cette commande, le serveur redémarre automatiquement

# ── POST-INSTALL (s'exécute après le redémarrage si tâche planifiée) ──────────
Write-Step "Post-installation" "Green"

# Supprimer la tâche planifiée créée au step 1
Unregister-ScheduledTask -TaskName "BillU_ADDS_Install" -Confirm:$false -EA SilentlyContinue
Write-OK "Tâche planifiée de démarrage supprimée"

# Vérifier la réplication
Write-INFO "Vérification de la réplication AD..."
Start-Sleep -Seconds 30
try {
    $results = repadmin /showrepl 2>&1
    if ($results -match "0 consecutive failure") { Write-OK "Réplication AD : OK" }
    else { Write-WARN "Vérifier manuellement : repadmin /showrepl" }
} catch { Write-WARN "repadmin non disponible — vérifier manuellement" }

Write-Step "=== INSTALLATION TERMINÉE ===" "Green"
Write-Host ""
Write-Host "  [OK]  AD-DS installé sur $($config.ServerName)" -ForegroundColor Green
Write-Host ""
Write-Host "  Vérifications à faire :" -ForegroundColor Yellow
Write-Host "    Get-ADDomainController -Filter *    # Lister les DC"
Write-Host "    repadmin /showrepl                  # Statut réplication"
Write-Host "    Get-ADReplicationPartnerMetadata -Target '$($config.ServerName)' -Scope Domain"
Write-Host ""

# ── FONCTION HELPER : MASQUE → PREFIX ────────────────────────────────────────
function ConvertTo-Prefix([string]$mask) {
    $bytes = $mask.Split('.') | ForEach-Object { [Convert]::ToInt32($_, 10) }
    $bits  = $bytes | ForEach-Object { [Convert]::ToString($_, 2).PadLeft(8,'0') }
    return ($bits -join '').Replace('0','').Length
}
