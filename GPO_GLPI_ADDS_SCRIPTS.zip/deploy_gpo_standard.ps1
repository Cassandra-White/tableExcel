#Requires -Modules GroupPolicy, ActiveDirectory
<#
.SYNOPSIS  Deploy GPO STANDARD (fond ecran, lecteurs, alimentation...) - BillU Groupe 1
.NOTES     Exécuter depuis le DC GUI ou PC Admin (RSAT + GPMC requis)
           Usage : .\deploy_gpo_standard.ps1
                   .\deploy_gpo_standard.ps1 -DomainName "billu.local" -OUPath "OU=BillU,DC=billu,DC=local"

           PREREQUIS PARTAGE RESEAU :
             - Creer \\DC1\NETLOGON\Wallpaper\ et y placer billu_wallpaper.jpg
             - Creer \\DC1\Partages\Users\  (pour redirection dossiers)
#>
[CmdletBinding()]
param(
    [string]$DomainName  = "billu.local",
    [string]$OUPath      = "OU=BillU,DC=billu,DC=local",
    [string]$DCName      = "DC1",
    [string]$WallpaperUNC = "\\DC1\NETLOGON\Wallpaper\billu_wallpaper.jpg"
)

function Write-Step($M,$C="Cyan") { Write-Host "`n[$([datetime]::Now.ToString('HH:mm:ss'))] $M" -ForegroundColor $C }
function Write-OK($M)   { Write-Host "  [OK]  $M" -ForegroundColor Green  }
function Write-SKIP($M) { Write-Host "  [~~]  $M (existant)" -ForegroundColor Yellow }
function Write-ERR($M)  { Write-Host "  [!!]  $M" -ForegroundColor Red    }
function Write-INFO($M) { Write-Host "  [i]   $M" -ForegroundColor DarkCyan }

function New-GPOSafe($Name,$Comment) {
    $g = Get-GPO -Name $Name -ErrorAction SilentlyContinue
    if ($g) { Write-SKIP $Name; return $g }
    $g = New-GPO -Name $Name -Comment $Comment -Domain $DomainName
    Write-OK "GPO creee : $Name"; return $g
}
function Link-GPOSafe($Name,$Target) {
    try   { New-GPLink -Name $Name -Target $Target -Domain $DomainName -EA Stop | Out-Null; Write-OK "Liee a $Target" }
    catch { if ($_.Exception.Message -match "already") { Write-SKIP "Lien" } else { Write-ERR $_.Exception.Message } }
}
function Set-Reg($GPO,$Key,$Val,$Data,$Type="DWORD") {
    Set-GPRegistryValue -Name $GPO -Key $Key -ValueName $Val -Value $Data -Type $Type -Domain $DomainName | Out-Null
}

# -- PREREQUIS -----------------------------------------------------------------
Write-Step "Verification des prerequis" "White"
try { Import-Module GroupPolicy,ActiveDirectory -EA Stop; Write-OK "Modules charges" }
catch { Write-ERR "RSAT manquant - Install-WindowsFeature GPMC,RSAT-AD-Tools"; exit 1 }
$dn = (Get-ADDomain $DomainName).DistinguishedName
Write-OK "Domaine : $dn"

# -- GPO STD 1 : FOND D'ECRAN -------------------------------------------------
Write-Step "GPO STD 1 - Fond d'ecran BillU"
New-GPOSafe "BillU-STD-01-Wallpaper" "Fond d'ecran corporate BillU"

$wpKey = "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System"
Set-Reg "BillU-STD-01-Wallpaper" $wpKey "Wallpaper"      $WallpaperUNC  "String"
Set-Reg "BillU-STD-01-Wallpaper" $wpKey "WallpaperStyle" "4"            "String" # 4 = etiree
Set-Reg "BillU-STD-01-Wallpaper" $wpKey "NoChangingWallpaper" 1   # Empeche les users de changer

Write-OK "Wallpaper : $WallpaperUNC | Style etire | Modification bloquee"
Write-INFO "Placer le fichier dans : \\$DCName\NETLOGON\Wallpaper\billu_wallpaper.jpg"
Link-GPOSafe "BillU-STD-01-Wallpaper" $OUPath

# -- GPO STD 2 : MAPPAGE DE LECTEURS ------------------------------------------
Write-Step "GPO STD 2 - Mappage de lecteurs reseau"
New-GPOSafe "BillU-STD-02-DriveMap" "Lecteurs reseau mappes automatiquement - BillU"

Write-INFO "Le mappage de lecteurs via GPO Preferences (Drive Maps) se configure via GUI :"
Write-INFO "GPMC > BillU-STD-02-DriveMap > Config utilisateur > Preferences > Parametres Windows > Mappages de lecteurs"
Write-INFO "   Action : Create  | Chemin : \\DC1\Partages\Commun  | Lettre : G:"
Write-INFO "   Action : Create  | Chemin : \\DC1\Partages\Users\%username%  | Lettre : H:"
Write-INFO "   Filtrage : Ciblage par groupe AD possible (ex: GRP_Compta -> lecteur K:)"

# Alternative registre pour un lecteur fixe (methode GPO Registry - moins flexible)
# Utiliser plutot la methode Preferences GUI pour les variables (%username%, %department%, etc.)
Write-OK "GPO creee - configurer les lecteurs via GPMC Preferences"
Link-GPOSafe "BillU-STD-02-DriveMap" $OUPath

# -- GPO STD 3 : GESTION DE L'ALIMENTATION ------------------------------------
Write-Step "GPO STD 3 - Gestion de l'alimentation"
New-GPOSafe "BillU-STD-03-Power" "Alimentation - PC : veille 30 min, ecrans 15 min - BillU"

$pwrKey = "HKLM\SOFTWARE\Policies\Microsoft\Power\PowerSettings"
# Profil equilibre : GUID 381b4222-f694-41f0-9685-ff5bb260df2e
$profil  = "HKLM\SOFTWARE\Policies\Microsoft\Power\PowerSettings\381b4222-f694-41f0-9685-ff5bb260df2e"
# Timeout ecran (AC = secteur, DC = batterie) en secondes
Set-Reg "BillU-STD-03-Power" $profil "ACSettingIndex"  900   # 15 min sur secteur
Set-Reg "BillU-STD-03-Power" $profil "DCSettingIndex"  300   # 5 min sur batterie

# Veille systeme via registre HKLM (plus universel)
$sysKey = "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\238C9FA8-0AAD-41ED-83F4-97BE242C8F20\29F6C1DB-86DA-48C5-9FDB-F2B67B1F44DA"
Set-Reg "BillU-STD-03-Power" "HKLM\SOFTWARE\Policies\Microsoft\Power\PowerSettings\238C9FA8-0AAD-41ED-83F4-97BE242C8F20\29F6C1DB-86DA-48C5-9FDB-F2B67B1F44DA" "ACSettingIndex"  1800  # 30 min veille secteur
Set-Reg "BillU-STD-03-Power" "HKLM\SOFTWARE\Policies\Microsoft\Power\PowerSettings\238C9FA8-0AAD-41ED-83F4-97BE242C8F20\29F6C1DB-86DA-48C5-9FDB-F2B67B1F44DA" "DCSettingIndex"  900   # 15 min veille batterie

Write-OK "Alimentation : ecran 15min (secteur) | Veille 30min | Batterie : ecran 5min, veille 15min"
Link-GPOSafe "BillU-STD-03-Power" $OUPath

# -- GPO STD 4 : REDIRECTION DE DOSSIERS --------------------------------------
Write-Step "GPO STD 4 - Redirection de dossiers (Documents & Bureau)"
New-GPOSafe "BillU-STD-04-FolderRedirection" "Redirection Documents et Bureau vers serveur - BillU"

Write-INFO "La redirection de dossiers se configure via GPMC :"
Write-INFO "  Config utilisateur > Parametres Windows > Redirection de dossiers"
Write-INFO "  Documents : Chemin = \\DC1\Partages\Users\%username%\Documents"
Write-INFO "  Bureau    : Chemin = \\DC1\Partages\Users\%username%\Bureau"
Write-INFO "  Options   : Cocher 'Accorder a l'utilisateur des droits exclusifs'"
Write-INFO "  Note : S'assurer que le partage \\DC1\Partages\Users\ existe avec les droits NTFS"

# Creer le partage si non existant
$sharePath = "C:\Partages\Users"
if (-not (Test-Path $sharePath)) {
    New-Item -ItemType Directory -Path $sharePath -Force | Out-Null
    New-SMBShare -Name "Users" -Path $sharePath -FullAccess "Domain Admins" -ChangeAccess "Authenticated Users" -EA SilentlyContinue | Out-Null
    Write-OK "Dossier + partage crees : $sharePath -> \\$env:COMPUTERNAME\Users"
}
Link-GPOSafe "BillU-STD-04-FolderRedirection" $OUPath

# -- GPO STD 5 : CONFIGURATION FIREFOX ----------------------------------------
Write-Step "GPO STD 5 - Configuration Firefox"
New-GPOSafe "BillU-STD-05-Firefox" "Parametres Firefox BillU (page accueil, plugins, etc.)"

Write-INFO "Firefox se configure via ADMX Mozilla. Copier les ADMX dans :"
Write-INFO "  \\$DCName\SYSVOL\$DomainName\Policies\PolicyDefinitions\"
Write-INFO "  Telecharger : https://github.com/mozilla/policy-templates/releases"

# En attendant les ADMX, configuration via registre (methode universelle)
$ff = "HKLM\SOFTWARE\Policies\Mozilla\Firefox"
Set-Reg "BillU-STD-05-Firefox" $ff "DisableTelemetry"       1
Set-Reg "BillU-STD-05-Firefox" $ff "DisableFormHistory"     1
Set-Reg "BillU-STD-05-Firefox" $ff "OfferToSaveLogins"      0
Set-Reg "BillU-STD-05-Firefox" $ff "DisablePrivateBrowsing" 1
Set-Reg "BillU-STD-05-Firefox" "$ff\Homepage" "URL"  "https://intranet.billu.local" "String"
Set-Reg "BillU-STD-05-Firefox" "$ff\Homepage" "StartPage" "homepage" "String"
Set-Reg "BillU-STD-05-Firefox" $ff "BlockAboutConfig"       1  # Interdit about:config
Write-OK "Firefox : telemetrie OFF | Sauvegarde MDP OFF | Page accueil = intranet.billu.local"
Link-GPOSafe "BillU-STD-05-Firefox" $OUPath

# -- GPO STD 6 : SCRIPT DE DEMARRAGE ------------------------------------------
Write-Step "GPO STD 6 - Scripts de demarrage (Logon utilisateur)"
New-GPOSafe "BillU-STD-06-LogonScript" "Script de connexion utilisateur - BillU"

# Creer le script dans NETLOGON
$scriptContent = @'
@echo off
REM ── Script de connexion BillU ─────────────────────────────────────────────
REM  Executer a chaque connexion utilisateur au domaine
echo [BillU] Application des parametres utilisateur...

REM Synchroniser l'heure
net time \\DC1 /set /y >nul 2>&1

REM Mapper le lecteur H: vers le profil utilisateur (fallback si GPO Preferences echoue)
if not exist H:\ net use H: \\DC1\Users\%username% /persistent:no >nul 2>&1

REM Mapper le lecteur G: (partage commun)
if not exist G:\ net use G: \\DC1\Partages\Commun /persistent:no >nul 2>&1

REM Message de bienvenue (optionnel)
echo [BillU] Connexion au domaine %userdomain% reussie. Bonjour %username% !
'@

$netlogonPath = "\\$DCName\NETLOGON"
if (Test-Path $netlogonPath) {
    $scriptContent | Out-File -FilePath "$netlogonPath\logon_billu.bat" -Encoding ASCII -Force
    Write-OK "Script depose dans $netlogonPath\logon_billu.bat"
} else {
    Write-INFO "Deposer manuellement logon_billu.bat dans \\$DCName\NETLOGON\"
}

# Lier le script a la GPO via Set-GPRegistryValue (methode registre - compatible)
Set-GPRegistryValue -Name "BillU-STD-06-LogonScript" -Domain $DomainName `
    -Key "HKCU\Software\Microsoft\Windows\CurrentVersion\Group Policy\Scripts\Logon\0\0" `
    -ValueName "Script"     -Value "\\$DCName\NETLOGON\logon_billu.bat" -Type "String" | Out-Null
Set-GPRegistryValue -Name "BillU-STD-06-LogonScript" -Domain $DomainName `
    -Key "HKCU\Software\Microsoft\Windows\CurrentVersion\Group Policy\Scripts\Logon\0\0" `
    -ValueName "Parameters" -Value "" -Type "String" | Out-Null
Write-OK "Script de connexion : \\$DCName\NETLOGON\logon_billu.bat"
Link-GPOSafe "BillU-STD-06-LogonScript" $OUPath

# -- RECAP --------------------------------------------------------------------
Write-Step "=== RECAP ===" "White"
Get-GPO -All -Domain $DomainName | Where-Object { $_.DisplayName -like "BillU-STD*" } |
    Sort-Object DisplayName | ForEach-Object { Write-OK "$($_.DisplayName)" }

Write-Host "`n[OK] GPO Standard deployees !`n" -ForegroundColor Green
Write-Host "  ACTIONS MANUELLES RESTANTES :" -ForegroundColor Yellow
Write-Host "  1. Lecteurs : GPMC > BillU-STD-02-DriveMap > Config util > Preferences > Mappages de lecteurs"
Write-Host "  2. Redirection dossiers : GPMC > BillU-STD-04-FolderRedirection > Config util > Params Windows > Redirection"
Write-Host "  3. Admin local : GPMC > BillU-SEC-08-LocalAdmin > Config ordi > Preferences > Utilisateurs et groupes locaux"
Write-Host "  4. Fond d'ecran : placer billu_wallpaper.jpg dans \\$DCName\NETLOGON\Wallpaper\"
Write-Host "  5. Firefox ADMX : https://github.com/mozilla/policy-templates/releases`n"
