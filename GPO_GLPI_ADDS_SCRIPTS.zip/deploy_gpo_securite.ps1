#Requires -Modules GroupPolicy, ActiveDirectory
<#
.SYNOPSIS  Deploy GPO de SÉCURITÉ — BillU Groupe 1
.NOTES     Exécuter depuis le DC GUI ou PC Admin (RSAT + GPMC requis)
           Usage : .\deploy_gpo_securite.ps1
                   .\deploy_gpo_securite.ps1 -DomainName "billu.local" -OUPath "OU=BillU,DC=billu,DC=local"
#>
[CmdletBinding()]
param(
    [string]$DomainName = "billu.local",
    [string]$OUPath     = "OU=BillU,DC=billu,DC=local"
)

function Write-Step($M,$C="Cyan") { Write-Host "`n[$([datetime]::Now.ToString('HH:mm:ss'))] $M" -ForegroundColor $C }
function Write-OK($M)   { Write-Host "  [OK]  $M" -ForegroundColor Green  }
function Write-SKIP($M) { Write-Host "  [~~]  $M (existant)" -ForegroundColor Yellow }
function Write-ERR($M)  { Write-Host "  [!!]  $M" -ForegroundColor Red   }

function New-GPOSafe($Name,$Comment) {
    $g = Get-GPO -Name $Name -ErrorAction SilentlyContinue
    if ($g) { Write-SKIP $Name; return $g }
    $g = New-GPO -Name $Name -Comment $Comment -Domain $DomainName
    Write-OK "GPO creee : $Name"; return $g
}
function Link-GPOSafe($Name,$Target) {
    try   { New-GPLink -Name $Name -Target $Target -Domain $DomainName -EA Stop | Out-Null; Write-OK "Liee a $Target" }
    catch { if ($_.Exception.Message -match "already") { Write-SKIP "Lien" } else { Write-ERR $_.Exception.Message } }
}
function Set-Reg($GPO,$Key,$Val,$Data,$Type="DWORD") {
    Set-GPRegistryValue -Name $GPO -Key $Key -ValueName $Val -Value $Data -Type $Type -Domain $DomainName | Out-Null
}

# -- PREREQUIS -----------------------------------------------------------------
Write-Step "Verification des prerequis" "White"
try { Import-Module GroupPolicy,ActiveDirectory -EA Stop; Write-OK "Modules charges" }
catch { Write-ERR "RSAT manquant - Install-WindowsFeature GPMC,RSAT-AD-Tools"; exit 1 }
$dn = (Get-ADDomain $DomainName).DistinguishedName
Write-OK "Domaine : $dn"

# -- GPO 1 : POLITIQUE MOT DE PASSE -------------------------------------------
Write-Step "GPO 1 - Politique de mot de passe"
New-GPOSafe "BillU-SEC-01-Password" "Complexite MDP - BillU"
Set-ADDefaultDomainPasswordPolicy -Identity $DomainName `
    -MinPasswordLength 12 -PasswordHistoryCount 10 `
    -MaxPasswordAge ([TimeSpan]::FromDays(90)) -MinPasswordAge ([TimeSpan]::FromDays(1)) `
    -ComplexityEnabled $true -ReversibleEncryptionEnabled $false
Write-OK "Longueur min=12 | Historique=10 | Expiration=90j | Complexite=ON"
Link-GPOSafe "BillU-SEC-01-Password" $dn

# -- GPO 2 : VERROUILLAGE DE COMPTE -------------------------------------------
Write-Step "GPO 2 - Verrouillage de compte"
New-GPOSafe "BillU-SEC-02-Lockout" "Lockout apres 5 tentatives - BillU"
Set-ADDefaultDomainPasswordPolicy -Identity $DomainName `
    -LockoutThreshold 5 `
    -LockoutDuration ([TimeSpan]::FromMinutes(30)) `
    -LockoutObservationWindow ([TimeSpan]::FromMinutes(30))
Write-OK "5 tentatives incorrectes -> lock 30 min | Fenetre = 30 min"
Link-GPOSafe "BillU-SEC-02-Lockout" $dn

# -- GPO 3 : RESTRICTION INSTALLATION LOGICIELS (SRP) -------------------------
Write-Step "GPO 3 - Restriction installation logiciels"
New-GPOSafe "BillU-SEC-03-SoftwareRestrict" "Interdit install logiciels non-admins - BillU"
$srpKey = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Safer\CodeIdentifiers"
Set-Reg "BillU-SEC-03-SoftwareRestrict" $srpKey "DefaultLevel"        262144  # Tout bloque par defaut
Set-Reg "BillU-SEC-03-SoftwareRestrict" $srpKey "PolicyScope"         0       # 0=Tout le monde
Set-Reg "BillU-SEC-03-SoftwareRestrict" $srpKey "TransparentEnabled"  1
Set-Reg "BillU-SEC-03-SoftwareRestrict" $srpKey "LogFileName" "%systemroot%\System32\LogFiles\SRP\srp.log" "String"
Write-OK "SRP : execution bloquee par defaut sauf dossiers systeme"
Link-GPOSafe "BillU-SEC-03-SoftwareRestrict" $OUPath

# -- GPO 4 : WINDOWS UPDATE ---------------------------------------------------
Write-Step "GPO 4 - Gestion Windows Update"
New-GPOSafe "BillU-SEC-04-WindowsUpdate" "Config Windows Update centralisee - BillU"
$wuAU = "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
$wuWU = "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
Set-Reg "BillU-SEC-04-WindowsUpdate" $wuAU "AUOptions"                    4   # Telecharger + planifier
Set-Reg "BillU-SEC-04-WindowsUpdate" $wuAU "ScheduledInstallDay"           0   # 0 = tous les jours
Set-Reg "BillU-SEC-04-WindowsUpdate" $wuAU "ScheduledInstallTime"          3   # 3h00 du matin
Set-Reg "BillU-SEC-04-WindowsUpdate" $wuAU "NoAutoUpdate"                  0   # Update activees
Set-Reg "BillU-SEC-04-WindowsUpdate" $wuAU "NoAutoRebootWithLoggedOnUsers" 1   # Pas de reboot si user co.
Set-Reg "BillU-SEC-04-WindowsUpdate" $wuWU "SetAutoRestartDeadline"        1
Set-Reg "BillU-SEC-04-WindowsUpdate" $wuWU "AutoRestartDeadlinePeriodInDays" 3
Write-OK "WU : installation a 3h00 | Reboot force apres 3j si user connecte"
Link-GPOSafe "BillU-SEC-04-WindowsUpdate" $OUPath

# -- GPO 5 : BLOCAGE BASE DE REGISTRE -----------------------------------------
Write-Step "GPO 5 - Blocage base de registre"
New-GPOSafe "BillU-SEC-05-NoRegedit" "Interdit regedit aux users standards - BillU"
Set-Reg "BillU-SEC-05-NoRegedit" `
    "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" `
    "DisableRegistryTools" 2  # 2 = bloque avec message d'erreur
Write-OK "Regedit bloque (DisableRegistryTools=2)"
Link-GPOSafe "BillU-SEC-05-NoRegedit" $OUPath

# -- GPO 6 : BLOCAGE PANNEAU DE CONFIGURATION ---------------------------------
Write-Step "GPO 6 - Blocage partiel du panneau de configuration"
New-GPOSafe "BillU-SEC-06-NoControlPanel" "Restreint le panneau de config - BillU"
$exp = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"
Set-Reg "BillU-SEC-06-NoControlPanel" $exp "DisallowCpl" 1  # Active la liste noire
$bl  = "$exp\DisallowedControlPanelItems"
Set-Reg "BillU-SEC-06-NoControlPanel" $bl "1" "Appwiz.cpl"    "String"  # Programmes & fonctionnalites
Set-Reg "BillU-SEC-06-NoControlPanel" $bl "2" "bthprops.cpl"  "String"  # Bluetooth
Set-Reg "BillU-SEC-06-NoControlPanel" $bl "3" "inetcpl.cpl"   "String"  # Options Internet
Set-Reg "BillU-SEC-06-NoControlPanel" $bl "4" "ncpa.cpl"      "String"  # Connexions reseau
Write-OK "Applets bloques : installation logiciels, Bluetooth, IE, Reseau"
Link-GPOSafe "BillU-SEC-06-NoControlPanel" $OUPath

# -- GPO 7 : RESTRICTION PERIPHERIQUES AMOVIBLES ------------------------------
Write-Step "GPO 7 - Restriction peripheriques amovibles (USB)"
New-GPOSafe "BillU-SEC-07-NoUSB" "Bloque lecture/ecriture USB/HDD/CD - BillU"
$rmv = "HKLM\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices"
foreach ($guid in @("{53f5630b-b6bf-11d0-94f2-00a0c91efb8b}", # USB Flash
                    "{53f56307-b6bf-11d0-94f2-00a0c91efb8b}", # HDD amovible
                    "{53f56308-b6bf-11d0-94f2-00a0c91efb8b}")) { # CD/DVD
    Set-Reg "BillU-SEC-07-NoUSB" "$rmv\$guid" "Deny_Read"  1
    Set-Reg "BillU-SEC-07-NoUSB" "$rmv\$guid" "Deny_Write" 1
}
Set-Reg "BillU-SEC-07-NoUSB" "$rmv\All" "Deny_All" 1
Write-OK "USB / HDD amovibles / CD-DVD : lecture et ecriture bloquees"
Link-GPOSafe "BillU-SEC-07-NoUSB" $OUPath

# -- GPO 8 : COMPTE ADMIN LOCAL (info GUI) ------------------------------------
Write-Step "GPO 8 - Compte admin local" "Yellow"
New-GPOSafe "BillU-SEC-08-LocalAdmin" "Ajoute BillU\GRP_Admins aux admins locaux - BillU"
Write-Host "  [i]  Configurer via GPMC > Preferences > Parametres Panel config > Utilisateurs et groupes locaux" -ForegroundColor DarkCyan
Write-Host "       Action : Update | Groupe : Administrateurs | Membres : BillU\GRP_Admins" -ForegroundColor DarkCyan
Link-GPOSafe "BillU-SEC-08-LocalAdmin" $OUPath

# -- GPO 9 : ECRAN DE VEILLE --------------------------------------------------
Write-Step "GPO 9 - Ecran de veille avec verrouillage"
New-GPOSafe "BillU-SEC-09-ScreenSaver" "Lock automatique apres 10 min - BillU"
$ss = "HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop"
Set-Reg "BillU-SEC-09-ScreenSaver" $ss "ScreenSaveActive"    "1"   "String"
Set-Reg "BillU-SEC-09-ScreenSaver" $ss "ScreenSaverIsSecure" "1"   "String"
Set-Reg "BillU-SEC-09-ScreenSaver" $ss "ScreenSaveTimeOut"   "600" "String"
Set-Reg "BillU-SEC-09-ScreenSaver" $ss "SCRNSAVE.EXE"        "scrnsave.scr" "String"
Write-OK "Veille : 10 min -> ecran + MDP au retour"
Link-GPOSafe "BillU-SEC-09-ScreenSaver" $OUPath

# -- GPO 10 : RDP SECURISE (NLA) ----------------------------------------------
Write-Step "GPO 10 - Bureau a distance securise (NLA)"
New-GPOSafe "BillU-SEC-10-RDP" "Force NLA + TLS pour le RDP - BillU"
$rdp = "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
Set-Reg "BillU-SEC-10-RDP" $rdp "UserAuthentication"   1   # NLA obligatoire
Set-Reg "BillU-SEC-10-RDP" $rdp "SecurityLayer"        2   # TLS uniquement
Set-Reg "BillU-SEC-10-RDP" $rdp "MinEncryptionLevel"   3   # Haute
Set-Reg "BillU-SEC-10-RDP" $rdp "fDisableEncryption"   0
Set-Reg "BillU-SEC-10-RDP" $rdp "MaxIdleTime"          1800000  # 30 min inactivite
Set-Reg "BillU-SEC-10-RDP" $rdp "MaxDisconnectionTime" 3600000  # 1h deconnecte
Write-OK "RDP : NLA + TLS + chiffrement haut | Idle = 30 min"
Link-GPOSafe "BillU-SEC-10-RDP" $OUPath

# -- GPO 11 : POLITIQUE POWERSHELL --------------------------------------------
Write-Step "GPO 11 - Politique de securite PowerShell"
New-GPOSafe "BillU-SEC-11-PowerShell" "ExecutionPolicy + journalisation PS - BillU"
$ps  = "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell"
Set-Reg "BillU-SEC-11-PowerShell" $ps  "EnableScripts"    1
Set-Reg "BillU-SEC-11-PowerShell" $ps  "ExecutionPolicy"  "RemoteSigned" "String"
$psb = "$ps\ScriptBlockLogging"
Set-Reg "BillU-SEC-11-PowerShell" $psb "EnableScriptBlockLogging"           1
Set-Reg "BillU-SEC-11-PowerShell" $psb "EnableScriptBlockInvocationLogging" 1
$pst = "$ps\Transcription"
Set-Reg "BillU-SEC-11-PowerShell" $pst "EnableTranscripting"    1
Set-Reg "BillU-SEC-11-PowerShell" $pst "EnableInvocationHeader" 1
Set-Reg "BillU-SEC-11-PowerShell" $pst "OutputDirectory"        "C:\PSLogs" "String"
Write-OK "PS : ExecutionPolicy=RemoteSigned | ScriptBlock logging ON | Transcription -> C:\PSLogs"
Link-GPOSafe "BillU-SEC-11-PowerShell" $OUPath

# -- RECAP --------------------------------------------------------------------
Write-Step "=== RECAP ===" "White"
Get-GPO -All -Domain $DomainName | Where-Object { $_.DisplayName -like "BillU-SEC*" } |
    Sort-Object DisplayName | ForEach-Object { Write-OK "$($_.DisplayName)" }
Write-Host "`n[OK] GPO Securite deployees !`n" -ForegroundColor Green
Write-Host "  Verifier  : Get-GPO -All | Where Name -like 'BillU-SEC*'"    -ForegroundColor DarkGray
Write-Host "  Appliquer : gpupdate /force  (depuis les postes clients)"     -ForegroundColor DarkGray
Write-Host "  Rapport   : Get-GPOReport -Name 'BillU-SEC-01-Password' -ReportType HTML -Path rapport.html`n"
