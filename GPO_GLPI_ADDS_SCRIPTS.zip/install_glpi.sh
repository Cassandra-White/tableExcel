#!/bin/bash
# ══════════════════════════════════════════════════════════════════════════════
#  install_glpi.sh — Installation automatisée de GLPI sur Debian CLI
#  Groupe 1 — BillU SIMPLON
#  Usage : sudo ./install_glpi.sh
#          sudo ./install_glpi.sh --config /chemin/vers/glpi.conf
# ══════════════════════════════════════════════════════════════════════════════
set -euo pipefail

# ── COULEURS ------------------------------------------------------------------
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

ok()   { echo -e "  ${GREEN}[OK]${RESET}  $*"; }
err()  { echo -e "  ${RED}[!!]${RESET}  $*" >&2; }
info() { echo -e "  ${CYAN}[i]${RESET}   $*"; }
step() { echo -e "\n${BOLD}${CYAN}[$(date +%H:%M:%S)]${RESET} ${BOLD}$*${RESET}"; }
warn() { echo -e "  ${YELLOW}[~~]${RESET}  $*"; }

# ── CHARGEMENT DE LA CONFIG ---------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/glpi.conf"

# Permet de passer --config /autre/chemin
while [[ $# -gt 0 ]]; do
    case "$1" in
        --config|-c) CONFIG_FILE="$2"; shift 2 ;;
        *) echo "Usage: $0 [--config fichier.conf]"; exit 1 ;;
    esac
done

if [[ ! -f "$CONFIG_FILE" ]]; then
    err "Fichier de configuration introuvable : $CONFIG_FILE"
    err "Créer glpi.conf en copiant glpi.conf.exemple"
    exit 1
fi

source "$CONFIG_FILE"
ok "Configuration chargée depuis $CONFIG_FILE"

# ── VÉRIFICATIONS INITIALES ---------------------------------------------------
step "Vérification des prérequis"

[[ "$EUID" -ne 0 ]] && { err "Exécuter en tant que root (sudo)"; exit 1; }
ok "Root OK"

# Debian/Ubuntu uniquement
if ! command -v apt-get &>/dev/null; then
    err "Ce script nécessite un système basé sur Debian/Ubuntu"
    exit 1
fi
ok "Système Debian détecté"

# ── LOG -----------------------------------------------------------------------
mkdir -p "$(dirname "$INSTALL_LOG")"
exec > >(tee -a "$INSTALL_LOG") 2>&1
info "Logs : $INSTALL_LOG"

# ── MISE À JOUR SYSTÈME -------------------------------------------------------
step "Mise à jour des paquets système"
apt-get update -qq
apt-get upgrade -y -qq
ok "Système mis à jour"

# ── INSTALLATION PHP + APACHE ─────────────────────────────────────────────────
step "Installation PHP $PHP_VERSION, Apache2 et extensions requises"

apt-get install -y -qq \
    apache2 \
    php${PHP_VERSION} \
    php${PHP_VERSION}-mysql \
    php${PHP_VERSION}-ldap \
    php${PHP_VERSION}-xml \
    php${PHP_VERSION}-xmlrpc \
    php${PHP_VERSION}-zip \
    php${PHP_VERSION}-gd \
    php${PHP_VERSION}-curl \
    php${PHP_VERSION}-mbstring \
    php${PHP_VERSION}-intl \
    php${PHP_VERSION}-bz2 \
    php${PHP_VERSION}-imap \
    php${PHP_VERSION}-cas \
    php${PHP_VERSION}-redis \
    php${PHP_VERSION}-apcu \
    libapache2-mod-php${PHP_VERSION} \
    curl wget unzip tar

ok "PHP $PHP_VERSION + Apache installés"

# Configurer PHP (upload et limites mémoire)
PHP_INI="/etc/php/${PHP_VERSION}/apache2/php.ini"
sed -i 's/^upload_max_filesize.*/upload_max_filesize = 20M/'  "$PHP_INI"
sed -i 's/^post_max_size.*/post_max_size = 20M/'             "$PHP_INI"
sed -i 's/^memory_limit.*/memory_limit = 256M/'              "$PHP_INI"
sed -i 's/^max_execution_time.*/max_execution_time = 600/'   "$PHP_INI"
sed -i "s|^;date.timezone.*|date.timezone = ${TIMEZONE}|"    "$PHP_INI"
ok "PHP configuré (upload 20M, mémoire 256M, timezone $TIMEZONE)"

# ── INSTALLATION MARIADB ──────────────────────────────────────────────────────
step "Installation et configuration MariaDB"

apt-get install -y -qq mariadb-server mariadb-client
systemctl enable --now mariadb
ok "MariaDB installé et démarré"

# Sécurisation MariaDB
mysql -u root <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED BY '${DB_ROOT_PASS}';
DELETE FROM mysql.user WHERE User='';
DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');
DROP DATABASE IF EXISTS test;
DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';
FLUSH PRIVILEGES;
EOF
ok "MariaDB sécurisé (root password configuré)"

# Créer la base GLPI et l'utilisateur dédié
mysql -u root -p"${DB_ROOT_PASS}" <<EOF
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
EOF
ok "Base de données '${DB_NAME}' créée | Utilisateur '${DB_USER}' configuré"

# ── TÉLÉCHARGEMENT ET INSTALLATION GLPI ──────────────────────────────────────
step "Téléchargement de GLPI $GLPI_VERSION"

mkdir -p "$TMP_DIR"
cd "$TMP_DIR"

if [[ ! -f "$GLPI_ARCHIVE" ]]; then
    info "Téléchargement depuis GitHub..."
    wget -q --show-progress "$GLPI_URL" -O "$GLPI_ARCHIVE"
fi
ok "Archive téléchargée : $GLPI_ARCHIVE"

step "Installation de GLPI dans $GLPI_DIR"

# Nettoyer si réinstallation
[[ -d "$GLPI_DIR" ]] && rm -rf "$GLPI_DIR"

tar -xzf "$GLPI_ARCHIVE" -C /tmp/
mv /tmp/glpi "$GLPI_DIR"
ok "GLPI extrait dans $GLPI_DIR"

# ── DÉPLACER LES DOSSIERS SENSIBLES HORS DU WEBROOT ──────────────────────────
step "Sécurisation : déplacement des dossiers sensibles"

# Structure sécurisée (recommandée depuis GLPI 10)
mkdir -p "$GLPI_DATA"  "$GLPI_LOG"  "$GLPI_CONFIG"

# Déplacer /files -> /var/lib/glpi (données)
[[ -d "${GLPI_DIR}/files" ]] && mv "${GLPI_DIR}/files" "${GLPI_DATA}/files"

# Déplacer /config -> /etc/glpi
[[ -d "${GLPI_DIR}/config" ]] && mv "${GLPI_DIR}/config" "${GLPI_CONFIG}/config"

# Créer les fichiers de redirection pour que GLPI retrouve ses dossiers
cat > "${GLPI_DIR}/inc/downstream.php" <<'PHPEOF'
<?php
define('GLPI_CONFIG_DIR', '/etc/glpi/config');
define('GLPI_VAR_DIR',    '/var/lib/glpi/files');
define('GLPI_LOG_DIR',    '/var/log/glpi');
PHPEOF

ok "Dossiers sensibles déplacés hors du webroot"

# ── DROITS ET PERMISSIONS ─────────────────────────────────────────────────────
step "Configuration des permissions"

chown -R ${WEB_USER}:${WEB_USER} "$GLPI_DIR"
chown -R ${WEB_USER}:${WEB_USER} "$GLPI_DATA"
chown -R ${WEB_USER}:${WEB_USER} "$GLPI_LOG"
chown -R ${WEB_USER}:${WEB_USER} "$GLPI_CONFIG"
chmod -R 750 "$GLPI_DIR"
chmod -R 750 "$GLPI_DATA"
chmod -R 750 "$GLPI_LOG"
ok "Permissions OK (propriétaire : $WEB_USER)"

# ── CONFIGURATION APACHE ──────────────────────────────────────────────────────
step "Configuration du VirtualHost Apache pour $DOMAIN"

cat > "/etc/apache2/sites-available/glpi.conf" <<APACHEEOF
<VirtualHost *:80>
    ServerName   ${DOMAIN}
    ServerAdmin  ${ADMIN_EMAIL}
    DocumentRoot ${GLPI_DIR}/public

    # Redirection vers HTTPS si disponible (décommenter si certificat SSL)
    # Redirect permanent / https://${DOMAIN}/

    <Directory ${GLPI_DIR}/public>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # Bloquer l'accès aux dossiers sensibles hors public/
    <Directory ${GLPI_DIR}>
        Require all denied
    </Directory>

    ErrorLog  ${GLPI_LOG}/apache_error.log
    CustomLog ${GLPI_LOG}/apache_access.log combined
</VirtualHost>
APACHEEOF

# Activer le site et les modules nécessaires
a2ensite glpi.conf
a2dissite 000-default.conf 2>/dev/null || true
a2enmod rewrite php${PHP_VERSION} headers
systemctl reload apache2
ok "VirtualHost Apache configuré et activé pour http://${DOMAIN}"

# ── INSTALLATION VIA CLI (base de données) ────────────────────────────────────
step "Initialisation de la base de données GLPI via CLI"

cd "$GLPI_DIR"
php bin/console db:install \
    --db-host="${DB_HOST}" \
    --db-port=3306 \
    --db-name="${DB_NAME}" \
    --db-user="${DB_USER}" \
    --db-password="${DB_PASS}" \
    --default-language="fr_FR" \
    --no-interaction \
    --force 2>&1 | tail -5

ok "Base de données initialisée"

# ── SÉCURISATION POST-INSTALL ─────────────────────────────────────────────────
step "Sécurisation post-installation"

# Supprimer le dossier install/ (obligatoire pour la sécurité)
[[ -d "${GLPI_DIR}/install" ]] && rm -rf "${GLPI_DIR}/install"
ok "Dossier install/ supprimé"

# Cron GLPI (maintenance, notifications, etc.)
echo "*/2 * * * * ${WEB_USER} php ${GLPI_DIR}/front/cron.php --force >> ${GLPI_LOG}/cron.log 2>&1" \
    > /etc/cron.d/glpi
ok "Cron GLPI configuré (toutes les 2 minutes)"

# ── RÉCAPITULATIF ─────────────────────────────────────────────────────────────
step "═══ INSTALLATION TERMINÉE ═══"
echo ""
echo -e "${GREEN}${BOLD}  GLPI $GLPI_VERSION installé avec succès !${RESET}"
echo ""
echo -e "  ${BOLD}URL            :${RESET} http://${DOMAIN}"
echo -e "  ${BOLD}Dossier GLPI   :${RESET} $GLPI_DIR"
echo -e "  ${BOLD}Données        :${RESET} $GLPI_DATA"
echo -e "  ${BOLD}Logs           :${RESET} $GLPI_LOG"
echo -e "  ${BOLD}Base de données:${RESET} $DB_NAME @ $DB_HOST"
echo ""
echo -e "  ${YELLOW}${BOLD}IDENTIFIANTS PAR DÉFAUT :${RESET}"
echo -e "  ${BOLD}  admin / admin${RESET}  ← CHANGER IMMÉDIATEMENT"
echo -e "  ${BOLD}  glpi  / glpi${RESET}"
echo -e "  ${BOLD}  post-only / postonly${RESET}"
echo -e "  ${BOLD}  tech / tech${RESET}"
echo ""
echo -e "  ${CYAN}${BOLD}ÉTAPES SUIVANTES :${RESET}"
echo -e "  1. Ouvrir http://${DOMAIN} depuis un navigateur"
echo -e "  2. Changer tous les mots de passe par défaut"
echo -e "  3. Configuration > Authentification > Annuaires LDAP"
echo -e "     Host: ${LDAP_HOST} | Base DN: ${LDAP_BASE_DN}"
echo -e "  4. Outils > Synchronisation LDAP"
echo ""
ok "Logs complets dans $INSTALL_LOG"
