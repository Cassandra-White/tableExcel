#Requires -RunAsAdministrator
# 04-Reset-ServiceGroups.ps1 -- BillU Sprint 5
# Annule le script 04 : vide tous les groupes GG_SVC_* de leurs membres
# Les groupes eux-memes sont conserves (crees par le script 02)

. ".\00-Config.ps1"

$DomInfo = Get-ADDomain -Credential $ADCredential
$SiteDN  = "OU=$SiteOU,OU=$CountryOU,OU=$RootOU,$($DomInfo.DistinguishedName)"
$OuSecu  = "OU=Groupes-Securite,OU=Groupes,$SiteDN"

Write-Host "=== RESET -- vidage des groupes GG_SVC_ ===" -ForegroundColor Yellow

$grps = Get-ADGroup -Filter { Name -like "GG_SVC_*" } `
    -SearchBase $OuSecu -Credential $ADCredential -EA SilentlyContinue

if (-not $grps) {
    Write-Host "[--] Aucun groupe GG_SVC_ trouve -- rien a faire"
    exit 0
}

$TotalRemoved = 0
foreach ($g in $grps) {
    $membres = Get-ADGroupMember -Identity $g.Name -Credential $ADCredential -EA SilentlyContinue
    if (-not $membres) {
        Write-Host "  [--] $($g.Name) : deja vide"
        continue
    }
    foreach ($m in $membres) {
        Remove-ADGroupMember -Identity $g.Name -Members $m.SamAccountName `
            -Credential $ADCredential -Confirm:$false
        $TotalRemoved++
    }
    Write-Host "  [OK] $($g.Name) vide ($($membres.Count) membres retires)"
}

Write-Host ""
Write-Host "=== $TotalRemoved membres retires des groupes GG_SVC_ ==="
Write-Host "    Les groupes GG_SVC_ sont conserves (geres par le script 02)"
Write-Host "    Vous pouvez relancer 04-Assign-ServiceGroups.ps1"
