#Requires -RunAsAdministrator
# 04-Assign-ServiceGroups.ps1 -- BillU Sprint 5
# Affecte chaque user actif a son groupe GG_SVC_[service]
# Source : attribut Description AD du user = CSVName du service
#          (renseignee par 03-Import-Users.ps1)
# Log    : C:\Windows\Logs\BillU\Assign-SvcGroups-[date].log

. ".\00-Config.ps1"

$DomInfo = Get-ADDomain -Credential $ADCredential
$SiteDN  = "OU=$SiteOU,OU=$CountryOU,OU=$RootOU,$($DomInfo.DistinguishedName)"
$LogDir  = "C:\Windows\Logs\BillU"
$LogFile = "$LogDir\Assign-SvcGroups-$(Get-Date -f yyyyMMdd-HHmm).log"
New-Item $LogDir -ItemType Directory -Force | Out-Null

function Log($msg) {
    $line = "[$(Get-Date -f HH:mm:ss)] $msg"
    Write-Host $line
    Add-Content $LogFile $line
}

# Construire l index CSVName -> OUName depuis $Departements (00-Config.ps1)
$SvcIdx = @{}
foreach ($D in $Departements) {
    foreach ($S in $D.Services) {
        $SvcIdx[$S.CSVName.ToLower().Trim()] = $S.OUName
    }
}
Log "Index services : $($SvcIdx.Count) entrees"

# Recuperer tous les users actifs avec leur Description
$users = Get-ADUser -Filter { Enabled -eq $true } `
    -SearchBase "OU=Utilisateurs,$SiteDN" -SearchScope Subtree `
    -Properties Description, MemberOf `
    -Credential $ADCredential

$Added = 0; $Skip = 0; $Deja = 0; $Err = 0

foreach ($u in $users) {
    $key = ($u.Description ?? "").ToLower().Trim()

    if (-not $key -or -not $SvcIdx.ContainsKey($key)) {
        Log "[SKIP] $($u.SamAccountName) -- Description vide ou service inconnu : '$key'"
        $Skip++
        continue
    }

    $grpName = "GG_SVC_$($SvcIdx[$key])"

    # Verifier que le groupe existe
    $grp = Get-ADGroup -Filter "Name -eq '$grpName'" -Credential $ADCredential -EA SilentlyContinue
    if (-not $grp) {
        Log "[ERR]  $($u.SamAccountName) -- groupe $grpName introuvable (script 02 lance ?)"
        $Err++
        continue
    }

    # Verifier si deja membre
    $isMember = $u.MemberOf | ForEach-Object {
        (Get-ADGroup $_ -EA SilentlyContinue).Name
    } | Where-Object { $_ -eq $grpName }

    if ($isMember) {
        Log "[DEJA] $($u.SamAccountName) -> $grpName"
        $Deja++
        continue
    }

    try {
        Add-ADGroupMember -Identity $grpName -Members $u.SamAccountName `
            -Credential $ADCredential -ErrorAction Stop
        Log "[OK]   $($u.SamAccountName) -> $grpName"
        $Added++
    } catch {
        Log "[ERR]  $($u.SamAccountName) -> $grpName : $_"
        $Err++
    }
}

Write-Host ""
Write-Host "=== Resultat ==="
Write-Host "  Ajoutes  : $Added"
Write-Host "  Deja OK  : $Deja"
Write-Host "  Sautes   : $Skip"
Write-Host "  Erreurs  : $Err"
Write-Host "  Log      : $LogFile"
