#Requires -RunAsAdministrator
# 05-Reset-Shares.ps1 -- BillU Sprint 5
# Annule le script 05 : supprime les 3 partages SMB
# Les dossiers D:\Partages\* et leurs contenus sont conserves

$sharesToDelete = @("Homes","Services","Departements")

Write-Host "=== RESET -- suppression des partages SMB ===" -ForegroundColor Yellow

$Deleted = 0; $Absent = 0
foreach ($name in $sharesToDelete) {
    if (Get-SmbShare -Name $name -EA SilentlyContinue) {
        Remove-SmbShare -Name $name -Force
        Write-Host "  [OK] Partage $name supprime"
        $Deleted++
    } else {
        Write-Host "  [--] Partage $name absent"
        $Absent++
    }
}

Write-Host ""
Write-Host "=== $Deleted partages supprimes | $Absent absents ==="
Write-Host "    Les dossiers D:\Partages\* et leurs ACL NTFS sont conserves"
Write-Host "    Vous pouvez relancer 05-Create-Shares.ps1"

Write-Host ""
Write-Host "=== Partages SMB restants sur ce serveur ==="
Get-SmbShare | Where-Object { $_.Name -notlike "ADMIN$" -and $_.Name -notlike "IPC$" -and $_.Name -notlike "C$" -and $_.Name -notlike "D$" } |
    Format-Table Name, Path
