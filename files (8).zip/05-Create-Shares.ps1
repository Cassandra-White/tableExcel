#Requires -RunAsAdministrator
# 05-Create-Shares.ps1 -- BillU Sprint 5
# Cree les 3 partages SMB : Homes (I:), Services (J:), Departements (K:)
# SIDs utilises pour FullAccess (invariants FR/EN) :
#   S-1-5-32-544 = Administrators / Administrateurs
#   S-1-5-18     = SYSTEM
#   SID Domain Admins + SID GG_DSI_Admins via Get-ADGroup

. ".\00-Config.ps1"

$DomInfo = Get-ADDomain -Credential $ADCredential

# SIDs des comptes/groupes admin
$sidAdmins    = [System.Security.Principal.SecurityIdentifier]"S-1-5-32-544"
$sidSystem    = [System.Security.Principal.SecurityIdentifier]"S-1-5-18"
$sidDomAdmins = (Get-ADGroup "Domain Admins"  -Credential $ADCredential).SID
$sidDSIAdmins = (Get-ADGroup "GG_DSI_Admins"  -Credential $ADCredential).SID

# Convertir les SIDs en NTAccount pour New-SmbShare (qui accepte des chaines)
function SID-ToName([System.Security.Principal.SecurityIdentifier]$sid) {
    return $sid.Translate([System.Security.Principal.NTAccount]).Value
}

$fullAccess = @(
    (SID-ToName $sidAdmins),
    (SID-ToName $sidSystem),
    (SID-ToName $sidDomAdmins),
    (SID-ToName $sidDSIAdmins)
)

Write-Host "=== Comptes avec FullAccess sur les partages SMB ==="
$fullAccess | ForEach-Object { Write-Host "  - $_" }
Write-Host ""

$shares = @(
    @{ Name="Homes";        Path="D:\Partages\Homes";        Desc="Dossiers individuels I:" },
    @{ Name="Services";     Path="D:\Partages\Services";     Desc="Dossiers de service J:"  },
    @{ Name="Departements"; Path="D:\Partages\Departements"; Desc="Dossiers de departement K:" }
)

foreach ($s in $shares) {
    # Verifier que le dossier source existe
    if (-not (Test-Path $s.Path)) {
        Write-Host "  [ERR] Dossier manquant : $($s.Path) -- lancer le script 02 d abord"
        continue
    }

    # Supprimer si existe deja (idempotent)
    Remove-SmbShare -Name $s.Name -Force -ErrorAction SilentlyContinue

    New-SmbShare `
        -Name                 $s.Name `
        -Path                 $s.Path `
        -Description          $s.Desc `
        -FullAccess           $fullAccess `
        -ChangeAccess         "Authenticated Users" `
        -FolderEnumerationMode AccessBased | Out-Null
    # AccessBased : les users ne voient que les sous-dossiers auxquels ils ont acces

    Write-Host "  [OK] \\DC1\$($s.Name)  ->  $($s.Path)"
}

Write-Host ""
Write-Host "=== Partages actifs ==="
Get-SmbShare | Where-Object { $_.Name -in @("Homes","Services","Departements") } |
    Format-Table Name, Path, Description

Write-Host ""
Write-Host "=== Permissions SMB sur Homes ==="
Get-SmbShareAccess -Name "Homes" | Format-Table AccountName, AccessControlType, AccessRight
