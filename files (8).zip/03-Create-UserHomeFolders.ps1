#Requires -RunAsAdministrator
# 03-Create-UserHomeFolders.ps1 -- BillU Sprint 5
# Cree D:\Partages\Homes\[login] pour chaque user actif
# SIDs utilises (invariants FR/EN) :
#   S-1-5-32-544 = Administrators / Administrateurs
#   S-1-5-18     = SYSTEM
#   SID Domain Admins recupere via Get-ADGroup

. ".\00-Config.ps1"

$DomInfo   = Get-ADDomain -Credential $ADCredential
$SiteDN    = "OU=$SiteOU,OU=$CountryOU,OU=$RootOU,$($DomInfo.DistinguishedName)"
$HomesRoot = "D:\Partages\Homes"
$Created   = 0

$inh  = [System.Security.AccessControl.InheritanceFlags]"ContainerInherit,ObjectInherit"
$prop = [System.Security.AccessControl.PropagationFlags]::None
$alw  = [System.Security.AccessControl.AccessControlType]::Allow
$full = [System.Security.AccessControl.FileSystemRights]::FullControl

# SIDs admins (invariants quelle que soit la langue Windows)
$sidAdmins    = [System.Security.Principal.SecurityIdentifier]"S-1-5-32-544"
$sidSystem    = [System.Security.Principal.SecurityIdentifier]"S-1-5-18"
$sidDomAdmins = (Get-ADGroup "Domain Admins" -Credential $ADCredential).SID

$users = Get-ADUser -Filter { Enabled -eq $true } `
    -SearchBase "OU=Utilisateurs,$SiteDN" -SearchScope Subtree `
    -Credential $ADCredential

foreach ($u in $users) {
    $dir = "$HomesRoot\$($u.SamAccountName)"
    if (Test-Path $dir) {
        Write-Host "  [--] Existe deja : $dir"
        continue
    }

    New-Item $dir -ItemType Directory -Force | Out-Null

    $acl = New-Object System.Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)

    # Admins en premier via SID
    foreach ($sid in @($sidAdmins, $sidSystem, $sidDomAdmins)) {
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule(
            $sid, $full, $inh, $prop, $alw)))
    }

    # Proprietaire : FullControl sur son dossier uniquement
    $userSID = (Get-ADUser $u.SamAccountName -Credential $ADCredential).SID
    $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule(
        $userSID, $full, $inh, $prop, $alw)))

    Set-Acl $dir $acl
    Write-Host "  [OK] $dir"
    $Created++
}

Write-Host ""
Write-Host "=== $Created dossiers homes crees ==="
