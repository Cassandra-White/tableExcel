#Requires -RunAsAdministrator
# 03-Reset-UserHomeFolders.ps1 -- BillU Sprint 5
# Annule le script 03 : supprime tous les sous-dossiers de D:\Partages\Homes
# Le dossier racine Homes lui-meme est conserve (cree par le script 02)

$HomesRoot = "D:\Partages\Homes"

Write-Host "=== RESET -- suppression des dossiers Homes ===" -ForegroundColor Yellow

if (-not (Test-Path $HomesRoot)) {
    Write-Host "[--] $HomesRoot absent -- rien a faire"
    exit 0
}

# Reprendre le controle sur tous les sous-dossiers avant suppression
Write-Host "--- Reprise du controle NTFS ---"
& takeown /F "$HomesRoot" /R /D O /A 2>$null
& icacls  "$HomesRoot" /grant "Administrateurs:(OI)(CI)F" /T /C /Q 2>$null
& icacls  "$HomesRoot" /grant "Administrators:(OI)(CI)F"  /T /C /Q 2>$null
& icacls  "$HomesRoot" /grant "SYSTEM:(OI)(CI)F"          /T /C /Q 2>$null
Write-Host "  [OK] Controle repris"

# Supprimer uniquement les sous-dossiers (pas le dossier racine Homes)
$subs = Get-ChildItem $HomesRoot -Directory
$Count = 0
foreach ($d in $subs) {
    Remove-Item $d.FullName -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "  [OK] Supprime : $($d.FullName)"
    $Count++
}

Write-Host ""
Write-Host "=== $Count dossiers homes supprimes ==="
Write-Host "    Racine $HomesRoot conservee"
Write-Host "    Vous pouvez relancer 03-Create-UserHomeFolders.ps1"
