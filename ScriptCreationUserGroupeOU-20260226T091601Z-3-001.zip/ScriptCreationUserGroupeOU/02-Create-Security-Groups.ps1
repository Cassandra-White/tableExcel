# ============================================================================
# Script      : 02-Create-Security-Groups.ps1
# Description : Creation des groupes de securite Active Directory
# Prerequis   : 00-Config.ps1 dans le meme dossier + script 01 execute
# ============================================================================

<#
.SYNOPSIS
    Cree tous les groupes AD avec le compte $ADAdminUser.

.DESCRIPTION
    Tous les groupes sont crees sous OU=Groupes,OU=Paris,OU=France,OU=BillU,...
    Toutes les operations AD utilisent $ADCredential (defini dans 00-Config.ps1).

.PARAMETER LogFile
    Chemin du fichier de log (defaut : $LogBaseDir\Groups-Creation.log)

.PARAMETER WhatIf
    Mode simulation - aucun groupe cree

.EXAMPLE
    .\02-Create-Security-Groups.ps1
    .\02-Create-Security-Groups.ps1 -WhatIf
#>

[CmdletBinding()]
param(
    [string]$LogFile = "",
    [switch]$WhatIf
)

# ============================================================================
# CHARGEMENT CONFIG
# ============================================================================

$ConfigFile = Join-Path $PSScriptRoot "00-Config.ps1"
if (-not (Test-Path $ConfigFile)) { Write-Error "00-Config.ps1 introuvable : $ConfigFile"; exit 1 }
. $ConfigFile

if (-not $LogFile) { $LogFile = Join-Path $LogBaseDir "Groups-Creation.log" }

# ============================================================================
# INITIALISATION
# ============================================================================

$LogDir = Split-Path $LogFile -Parent
if (-not (Test-Path $LogDir)) { New-Item -Path $LogDir -ItemType Directory -Force | Out-Null }

try { Import-Module ActiveDirectory -ErrorAction Stop }
catch { Write-Error "Module ActiveDirectory non disponible. Installez RSAT."; exit 1 }

try {
    $DomainInfo = Get-ADDomain -Credential $ADCredential -ErrorAction Stop
}
catch {
    Write-Error "Echec d'authentification avec $ADAdminUser : $($_.Exception.Message)"
    exit 1
}

$DomainDN   = $DomainInfo.DistinguishedName
$DomainName = $DomainInfo.DNSRoot

$RootDN    = "OU=$RootOU,$DomainDN"
$CountryDN = "OU=$CountryOU,$RootDN"
$SiteDN    = "OU=$SiteOU,$CountryDN"

$Script:TotalGroups = 0; $Script:CreatedGroups = 0
$Script:ExistGroups = 0; $Script:ErrorGroups   = 0

# ============================================================================
# FONCTIONS
# ============================================================================

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','SUCCESS','WARNING','ERROR')]
        [string]$Level = 'INFO'
    )
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogFile -Value "[$ts] [$Level] $Message"
    switch ($Level) {
        'SUCCESS' { Write-Host $Message -ForegroundColor Green  }
        'WARNING' { Write-Host $Message -ForegroundColor Yellow }
        'ERROR'   { Write-Host $Message -ForegroundColor Red    }
        default   { Write-Host $Message -ForegroundColor White  }
    }
}

function New-Group {
    param(
        [string]$Name,
        [string]$Path,
        [string]$Description,
        [ValidateSet('Global','Universal','DomainLocal')]
        [string]$Scope    = 'Global',
        [ValidateSet('Security','Distribution')]
        [string]$Category = 'Security'
    )
    $Script:TotalGroups++

    try {
        if (Get-ADGroup -Filter "Name -eq '$Name'" -Credential $ADCredential -ErrorAction SilentlyContinue) {
            Write-Log "  (existe)  $Name" -Level WARNING
            $Script:ExistGroups++; return
        }
        if (-not (Get-ADOrganizationalUnit -Filter "DistinguishedName -eq '$Path'" `
                -Credential $ADCredential -ErrorAction SilentlyContinue)) {
            Write-Log "  ERREUR OU introuvable pour $Name : $Path  (script 01 execute ?)" -Level ERROR
            $Script:ErrorGroups++; return
        }
        if ($WhatIf) {
            Write-Log "  [SIM] $Name  [$Scope / $Category]" -Level INFO
            $Script:CreatedGroups++; return
        }

        New-ADGroup -Name $Name -Path $Path -GroupScope $Scope `
            -GroupCategory $Category -Description $Description `
            -Credential $ADCredential -ErrorAction Stop | Out-Null

        Write-Log "  + $Name  [$Scope / $Category]" -Level SUCCESS
        $Script:CreatedGroups++
    }
    catch {
        Write-Log "  ERREUR $Name : $($_.Exception.Message)" -Level ERROR
        $Script:ErrorGroups++
    }
}

# ============================================================================
# SCRIPT PRINCIPAL
# ============================================================================

Write-Log "========================================" -Level INFO
Write-Log "DEBUT - Creation groupes AD [$OrgName]"  -Level INFO
Write-Log "Compte  : $ADAdminUser"                  -Level INFO
Write-Log "Site    : $SiteDN"                       -Level INFO
if ($WhatIf) { Write-Log "!!! MODE SIMULATION !!!" -Level WARNING }
Write-Log "========================================" -Level INFO
Write-Host ""

$OU_Depts = "OU=Groupes-Departements,OU=Groupes,$SiteDN"
$OU_Fonct = "OU=Groupes-Fonctionnels,OU=Groupes,$SiteDN"
$OU_Secu  = "OU=Groupes-Securite,OU=Groupes,$SiteDN"

# -----------------------------------------------------------------------
# ETAPE 1 : GROUPES DEPARTEMENTS
# -----------------------------------------------------------------------

Write-Log "--- Groupes Departements ---" -Level INFO

foreach ($Dept in $Departements) {
    Write-Log "  [Dept] $($Dept.OUName)" -Level INFO

    New-Group -Name "GG_$($Dept.GroupCode)_Users" -Path $OU_Depts `
        -Description "Utilisateurs departement $($Dept.OUName)"

    if ($Dept.HasAdminGroup) {
        New-Group -Name "GG_$($Dept.GroupCode)_Admins" -Path $OU_Depts `
            -Description "Administrateurs departement $($Dept.OUName)"
    }
    if ($Dept.HasDistribGroup) {
        New-Group -Name "GD_$($Dept.GroupCode)" -Path $OU_Fonct `
            -Description "Liste distribution $($Dept.OUName)" `
            -Scope "Global" -Category "Distribution"
    }
}
Write-Host ""

# -----------------------------------------------------------------------
# ETAPE 2 : GROUPES FONCTIONNELS
# -----------------------------------------------------------------------

Write-Log "--- Groupes Fonctionnels ---" -Level INFO

foreach ($G in $GroupesFonctionnels) {
    New-Group -Name $G.Name -Path $OU_Fonct -Description $G.Description `
        -Scope $G.Scope -Category $G.Category
}
Write-Host ""

# -----------------------------------------------------------------------
# ETAPE 3 : GROUPES PARTAGES RESEAU
# -----------------------------------------------------------------------

Write-Log "--- Groupes Partages Reseau ---" -Level INFO

$PermDesc = @{ "RO" = "Lecture seule"; "RW" = "Lecture Ecriture"; "FULL" = "Controle total" }

foreach ($Partage in $PartagesConfig) {
    foreach ($Perm in $Partage.Permissions) {
        New-Group -Name "GG_$($Partage.DeptCode)_$Perm" -Path $OU_Secu `
            -Description "$($PermDesc[$Perm]) sur partage $($Partage.DeptCode)"
    }
}
Write-Host ""

# ============================================================================
# RECAPITULATIF
# ============================================================================

Write-Log "========================================" -Level INFO
Write-Log "RECAPITULATIF"                            -Level INFO
Write-Log "  Total traite  : $Script:TotalGroups"    -Level INFO
Write-Log "  Crees         : $Script:CreatedGroups"  -Level SUCCESS
Write-Log "  Existants     : $Script:ExistGroups"    -Level WARNING
Write-Log "  Erreurs       : $Script:ErrorGroups"    -Level ERROR
Write-Log "========================================" -Level INFO
Write-Host ""

if (-not $WhatIf) {
    $ExportPath = Join-Path $LogBaseDir "Security-Groups-$(Get-Date -Format 'yyyyMMdd-HHmmss').csv"
    Get-ADGroup -Filter * -SearchBase "OU=Groupes,$SiteDN" -Properties Description `
            -Credential $ADCredential |
        Select-Object Name, GroupScope, GroupCategory, Description, DistinguishedName |
        Export-Csv -Path $ExportPath -NoTypeInformation -Encoding UTF8
    Write-Log "Export groupes : $ExportPath" -Level SUCCESS
}

Write-Log "FIN - Creation groupes AD" -Level INFO
