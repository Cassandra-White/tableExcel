# ============================================================================
# Fichier : 00-Config.ps1
# Description : Configuration centrale pour les scripts AD BillU
#               Ce fichier est dot-sourcé par les scripts 01, 02 et 03.
#               Toute modification de la structure AD se fait ICI uniquement.
# ============================================================================

# ============================================================================
# PARAMÈTRES GÉNÉRAUX
# ============================================================================

$OrgName           = "BillU"
$DomainEmailSuffix = "billu.com"    # Laisser vide "" pour utiliser le DNSRoot AD
$LogBaseDir        = "C:\Logs"

# ============================================================================
# SOCIÉTÉ PRINCIPALE — FILTRE IMPORT CSV
# ============================================================================
# Seuls les employés dont le champ "Societe" = $SocietePrincipale sont importés.
# Les prestataires (I-magyne, 2Face, Livingston & Associés…) sont ignorés
# sauf si -ImportExterne est passé au script 03.

$SocietePrincipale = "BillU"

# ============================================================================
# OU ORDINATEURS — TOUJOURS PLATE (pas de sous-OUs)
# ============================================================================

$OuPCs = "Ordinateurs"

# ============================================================================
# OUs PRINCIPALES SUPPLÉMENTAIRES
# ============================================================================

$MainOUsExtra = @(
    @{ Name = "Comptes-Admin";   Description = "Comptes administrateurs à privilèges élevés" },
    @{ Name = "Comptes-Service"; Description = "Comptes de service pour applications et services" }
)

# ============================================================================
# DÉPARTEMENTS ET LEURS SERVICES
# ============================================================================
# IMPORTANT :
#   - "Name"    doit correspondre EXACTEMENT à la colonne "Departement" du CSV.
#   - "Services" contient les noms des sous-OUs à créer sous l'OU département.
#     Chaque valeur doit correspondre EXACTEMENT à la colonne "Service" du CSV.
#   - Si "Services" est vide (@()), les utilisateurs sont placés directement
#     dans l'OU département (ex : Direction, Service recrutement).
#
# GroupCode       : identifiant court MAJUSCULES pour les noms de groupes AD.
# HasAdminGroup   : génère GG_{GroupCode}_Admins si $true
# HasDistribGroup : génère GD_{GroupCode} (liste de distribution) si $true

$Departements = @(
    @{
        Name            = "Direction"
        Description     = "Direction générale et membres du comité exécutif"
        GroupCode       = "DIRECTION"
        HasAdminGroup   = $true
        HasDistribGroup = $true
        Services        = @()   # Pas de sous-OU service — utilisateurs directement dans l'OU
    },
    @{
        Name            = "Développement logiciel"
        Description     = "Équipe de développement logiciel"
        GroupCode       = "DEV"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            "analyse et conception",
            "Développement",
            "Recherche et Prototype",
            "Tests et qualité"
        )
    },
    @{
        Name            = "DSI"
        Description     = "Direction des Systèmes d'Information"
        GroupCode       = "DSI"
        HasAdminGroup   = $true
        HasDistribGroup = $true
        Services        = @(
            "Administration Systèmes et Réseaux",
            "Développement et Intégration",
            "Exploitation",
            "Support"
        )
    },
    @{
        Name            = "Service Commercial"
        Description     = "Service commercial, ventes, achats et service client"
        GroupCode       = "COMMERCIAL"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            "ADV",
            "B2B",
            "Service achat",
            "Service Client"
        )
    },
    @{
        Name            = "Communication et Relations publiques"
        Description     = "Service communication, relations médias et gestion des marques"
        GroupCode       = "COMM"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            "Communication interne",
            "Gestion des marques",
            "Relation Médias"
        )
    },
    @{
        Name            = "Département Juridique"
        Description     = "Service juridique, conformité et propriété intellectuelle"
        GroupCode       = "JURIDIQUE"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            "Droit des sociétés",
            "Propriété intellectuelle",
            "Protection des données et conformité"
        )
    },
    @{
        Name            = "Finance et Comptabilité"
        Description     = "Service finance, comptabilité et contrôle de gestion"
        GroupCode       = "FINANCE"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            "Finance",
            "Fiscalité",
            "Service Comptabilité"
        )
    },
    @{
        Name            = "QHSE"
        Description     = "Qualité, Hygiène, Sécurité, Environnement"
        GroupCode       = "QHSE"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @(
            "Certification",
            "Contrôle Qualité",
            "Gestion environnementale"
        )
    },
    @{
        Name            = "Service recrutement"
        Description     = "Service recrutement et ressources humaines"
        GroupCode       = "RH"
        HasAdminGroup   = $false
        HasDistribGroup = $false
        Services        = @()   # Pas de sous-OU service
    }
)

# ============================================================================
# SOUS-OUs DE L'OU GROUPES
# ============================================================================

$GroupSubOUs = @(
    @{ Name = "Groupes-Departements"; Description = "Groupes de sécurité par département" },
    @{ Name = "Groupes-Fonctionnels"; Description = "Groupes fonctionnels (VPN, WiFi, applications, etc.)" },
    @{ Name = "Groupes-Securite";     Description = "Groupes de sécurité pour accès aux ressources" }
)

# ============================================================================
# GROUPES FONCTIONNELS
# ============================================================================

$GroupesFonctionnels = @(
    @{ Name = "GG_VPN_Access";        Description = "Accès VPN pour connexion à distance";           Scope = "Global";    Category = "Security" },
    @{ Name = "GG_WiFi_Access";       Description = "Accès WiFi Corporate (802.1X WPA3-Enterprise)"; Scope = "Global";    Category = "Security" },
    @{ Name = "GG_PRINT_RDC";         Description = "Accès aux imprimantes Rez-de-Chaussée";         Scope = "Global";    Category = "Security" },
    @{ Name = "GG_PRINT_ETG1";        Description = "Accès aux imprimantes Étage 1";                 Scope = "Global";    Category = "Security" },
    @{ Name = "GG_PRINT_ETG2";        Description = "Accès aux imprimantes Étage 2";                 Scope = "Global";    Category = "Security" },
    @{ Name = "GG_APP_GLPI_Users";    Description = "Utilisateurs GLPI (ticketing)";                 Scope = "Global";    Category = "Security" },
    @{ Name = "GG_APP_GLPI_Admins";   Description = "Administrateurs GLPI";                          Scope = "Global";    Category = "Security" },
    @{ Name = "GG_APP_Zabbix_Users";  Description = "Utilisateurs Zabbix (monitoring)";              Scope = "Global";    Category = "Security" },
    @{ Name = "GG_APP_Zabbix_Admins"; Description = "Administrateurs Zabbix";                        Scope = "Global";    Category = "Security" },
    @{ Name = "GG_ALL_Employees";     Description = "Tous les employés de $OrgName";                 Scope = "Universal"; Category = "Security" }
)

# ============================================================================
# GROUPES DE SÉCURITÉ POUR LES PARTAGES RÉSEAU
# ============================================================================

$PartagesConfig = @(
    @{ DeptCode = "FINANCE";    Permissions = @("RO", "RW", "FULL") },
    @{ DeptCode = "JURIDIQUE";  Permissions = @("RO", "RW", "FULL") },
    @{ DeptCode = "DIRECTION";  Permissions = @("RO", "RW", "FULL") },
    @{ DeptCode = "DEV";        Permissions = @("RW") },
    @{ DeptCode = "COMMERCIAL"; Permissions = @("RW") },
    @{ DeptCode = "COMMUN";     Permissions = @("RW") }
)

# ============================================================================
# FIN DE LA CONFIGURATION
# ============================================================================
