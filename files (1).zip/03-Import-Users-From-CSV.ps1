# ============================================================================
# Script : 03-Import-Users-From-CSV.ps1
# Description : Import des utilisateurs BillU depuis le fichier CSV
# Prérequis : 00-Config.ps1 dans le même dossier + scripts 01 et 02 exécutés
# ============================================================================

<#
.SYNOPSIS
    Importe les utilisateurs BillU depuis le CSV (séparateur ";").

.DESCRIPTION
    Format CSV attendu (séparateur = ";") :
      Civilité;Prenom;Nom;Societe;Site;Departement;Service;Fonction;
      Manager-Prenom;Manager-Nom;Nom de PC;Marque PC;Date de naissance;
      Telephone fixe;Telephone portable

    Placement des utilisateurs :
      → Si l'utilisateur a un "Service" ET que la sous-OU service existe :
            OU=<Service>,OU=<Département>,OU=Utilisateurs,...
      → Sinon (Direction, Service recrutement, service vide) :
            OU=<Département>,OU=Utilisateurs,...

    Phases d'exécution :
      1. Création des comptes utilisateurs
      2. Affectation aux groupes de département + GG_ALL_Employees
      3. Configuration des relations manager
      4. Enregistrement des ordinateurs dans OU=Ordinateurs

.PARAMETER CSVFile
    Chemin du fichier CSV (défaut : .\BillUTableau.csv)

.PARAMETER Delimiter
    Séparateur du fichier CSV (défaut : ";")

.PARAMETER DefaultPassword
    Mot de passe initial (défaut : BillU2025!Temp)

.PARAMETER AddToGroups
    Ajouter les utilisateurs aux groupes département (défaut : $true)

.PARAMETER ImportOrdinateurs
    Créer les comptes ordinateurs dans OU=Ordinateurs (défaut : $true)

.PARAMETER ImportExterne
    Importer également les employés des sociétés externes (défaut : $false)

.PARAMETER LogFile
    Chemin du fichier de log (défaut : $LogBaseDir\Users-Import.log)

.PARAMETER WhatIf
    Mode simulation — aucun objet AD créé ou modifié

.EXAMPLE
    .\03-Import-Users-From-CSV.ps1
    .\03-Import-Users-From-CSV.ps1 -WhatIf
    .\03-Import-Users-From-CSV.ps1 -ImportExterne -ImportOrdinateurs:$false
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$CSVFile           = ".\BillUTableau.csv",
    [string]$Delimiter         = ";",
    [string]$DefaultPassword   = "BillU2025!Temp",
    [switch]$AddToGroups       = $true,
    [switch]$ImportOrdinateurs = $true,
    [switch]$ImportExterne,
    [string]$LogFile           = "",
    [switch]$WhatIf
)

# ============================================================================
# CHARGEMENT DE LA CONFIGURATION
# ============================================================================

$ConfigFile = Join-Path -Path $PSScriptRoot -ChildPath "00-Config.ps1"
if (-not (Test-Path $ConfigFile)) {
    Write-Error "Fichier de configuration introuvable : $ConfigFile"
    exit 1
}
. $ConfigFile

if (-not $LogFile) { $LogFile = Join-Path $LogBaseDir "Users-Import.log" }

# ============================================================================
# INITIALISATION
# ============================================================================

$LogDir = Split-Path -Path $LogFile -Parent
if (-not (Test-Path $LogDir)) { New-Item -Path $LogDir -ItemType Directory -Force | Out-Null }

try { Import-Module ActiveDirectory -ErrorAction Stop }
catch { Write-Error "Module ActiveDirectory non disponible. Installez RSAT."; exit 1 }

$DomainDN   = (Get-ADDomain).DistinguishedName
$DomainName = (Get-ADDomain).DNSRoot
$EmailDomain = if ($DomainEmailSuffix) { $DomainEmailSuffix } else { $DomainName }

$SecurePassword = ConvertTo-SecureString $DefaultPassword -AsPlainText -Force

# Mapping Département → Groupe (depuis config)
$DeptGroupMap = @{}
foreach ($Dept in $Departements) {
    $DeptGroupMap[$Dept.Name] = "GG_$($Dept.GroupCode)_Users"
}

# Index des services par département pour résolution rapide de l'OU cible
# Structure : $ServiceIndex["Département"]["Service"] = $true
$ServiceIndex = @{}
foreach ($Dept in $Departements) {
    $ServiceIndex[$Dept.Name] = @{}
    foreach ($Svc in $Dept.Services) {
        $ServiceIndex[$Dept.Name][$Svc] = $true
    }
}

# ============================================================================
# FONCTIONS
# ============================================================================

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','SUCCESS','WARNING','ERROR')]
        [string]$Level = 'INFO'
    )
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogFile -Value "[$Timestamp] [$Level] $Message"
    switch ($Level) {
        'SUCCESS' { Write-Host $Message -ForegroundColor Green  }
        'WARNING' { Write-Host $Message -ForegroundColor Yellow }
        'ERROR'   { Write-Host $Message -ForegroundColor Red    }
        default   { Write-Host $Message -ForegroundColor White  }
    }
}

function Remove-Accents {
    param([string]$Text)
    $Text = $Text -replace '[éèêë]','e' -replace '[àâä]','a' -replace '[ôö]','o'
    $Text = $Text -replace '[ùûü]','u' -replace 'ç','c' -replace '[ïî]','i' -replace 'ÿ','y'
    $Text = $Text -replace "[''`"]",'' -replace '[-\s]',''
    return $Text.ToLower()
}

function Clean-Value {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value) -or $Value.Trim() -eq '-') { return "" }
    return $Value.Trim()
}

function Get-UniqueLogin {
    param([string]$Prenom, [string]$Nom)
    $Base  = "$(Remove-Accents $Prenom).$(Remove-Accents $Nom)"
    $Login = $Base; $i = 2
    while (Get-ADUser -Filter "SamAccountName -eq '$Login'" -ErrorAction SilentlyContinue) {
        $Login = "$Base$i"; $i++
    }
    return $Login
}

function Resolve-TargetOU {
    <#
    .SYNOPSIS
        Retourne l'OU cible de l'utilisateur :
          - OU=Service,OU=Département,OU=Utilisateurs  si la sous-OU service existe dans la config
          - OU=Département,OU=Utilisateurs             sinon (service vide, Direction, RH…)
    #>
    param(
        [string]$Departement,
        [string]$Service
    )

    $DeptOU = "OU=$Departement,OU=Utilisateurs,$DomainDN"

    # Vérifier si ce département a des sous-OUs service ET si ce service y est listé
    if ($Service -and $ServiceIndex.ContainsKey($Departement) -and $ServiceIndex[$Departement].ContainsKey($Service)) {
        return "OU=$Service,$DeptOU"
    }

    return $DeptOU
}

function New-ADUserFromCSV {
    param(
        [PSCustomObject]$Row,
        [switch]$WhatIfMode
    )

    $Prenom      = Clean-Value $Row.Prenom
    $Nom         = Clean-Value $Row.Nom
    $Departement = Clean-Value $Row.Departement
    $Service     = Clean-Value $Row.Service
    $Fonction    = Clean-Value $Row.Fonction
    $TelFixe     = Clean-Value $Row.'Telephone fixe'
    $TelPort     = Clean-Value $Row.'Telephone portable'
    $NomPC       = Clean-Value $Row.'Nom de PC'
    $MarquePC    = Clean-Value $Row.'Marque PC'

    if (-not $Prenom -or -not $Nom) {
        Write-Log "  ✗ Ligne ignorée : Prénom ou Nom manquant" -Level ERROR
        return $false
    }

    # Login
    $Login = if ($WhatIfMode) {
        "$(Remove-Accents $Prenom).$(Remove-Accents $Nom)"
    } else {
        Get-UniqueLogin -Prenom $Prenom -Nom $Nom
    }

    $UPN         = "$Login@$DomainName"
    $DisplayName = "$Prenom $Nom"
    $Email       = "$Login@$EmailDomain"

    # Résolution de l'OU cible (département ou sous-OU service)
    $TargetOU = Resolve-TargetOU -Departement $Departement -Service $Service

    # Vérifier que l'OU cible existe dans AD
    if (-not (Get-ADOrganizationalUnit -Filter "DistinguishedName -eq '$TargetOU'" -ErrorAction SilentlyContinue)) {
        Write-Log "  ✗ OU introuvable : '$TargetOU' — $Login ignoré" -Level ERROR
        return $false
    }

    # Doublon
    if (-not $WhatIfMode -and (Get-ADUser -Filter "SamAccountName -eq '$Login'" -ErrorAction SilentlyContinue)) {
        Write-Log "  ⚠ Existe déjà : $Login" -Level WARNING
        return $null
    }

    # Paramètres de création
    $UserParams = @{
        Name                  = $DisplayName
        GivenName             = $Prenom
        Surname               = $Nom
        SamAccountName        = $Login
        UserPrincipalName     = $UPN
        EmailAddress          = $Email
        DisplayName           = $DisplayName
        Path                  = $TargetOU
        AccountPassword       = $SecurePassword
        Enabled               = $true
        ChangePasswordAtLogon = $true
        PasswordNeverExpires  = $false
        CannotChangePassword  = $false
    }

    if ($Fonction)    { $UserParams['Title']       = $Fonction    }
    if ($Departement) { $UserParams['Department']  = $Departement }
    if ($Service)     { $UserParams['Description'] = $Service     }  # Service → Description AD
    if ($TelFixe)     { $UserParams['OfficePhone'] = $TelFixe     }
    if ($TelPort)     { $UserParams['MobilePhone'] = $TelPort     }

    # Simulation
    if ($WhatIfMode) {
        $OUDisplay = if ($Service -and $ServiceIndex[$Departement][$Service]) {
            "$Departement > $Service"
        } else {
            "$Departement (direct)"
        }
        Write-Log "  [SIM] $Login ($DisplayName) | $OUDisplay" -Level INFO
        return @{
            Login         = $Login
            DisplayName   = $DisplayName
            Departement   = $Departement
            Service       = $Service
            ManagerPrenom = Clean-Value $Row.'Manager-Prenom'
            ManagerNom    = Clean-Value $Row.'Manager-Nom'
            NomPC         = $NomPC
            MarquePC      = $MarquePC
        }
    }

    # Création
    try {
        New-ADUser @UserParams -PassThru | Out-Null
        $OUDisplay = if ($Service -and $ServiceIndex[$Departement][$Service]) {
            "$Departement > $Service"
        } else {
            "$Departement"
        }
        Write-Log "  ✓ $Login ($DisplayName) | $OUDisplay" -Level SUCCESS
        return @{
            Login         = $Login
            DisplayName   = $DisplayName
            Departement   = $Departement
            Service       = $Service
            ManagerPrenom = Clean-Value $Row.'Manager-Prenom'
            ManagerNom    = Clean-Value $Row.'Manager-Nom'
            NomPC         = $NomPC
            MarquePC      = $MarquePC
        }
    }
    catch {
        Write-Log "  ✗ Erreur création $Login : $($_.Exception.Message)" -Level ERROR
        return $false
    }
}

# ============================================================================
# SCRIPT PRINCIPAL
# ============================================================================

Write-Log "========================================" -Level INFO
Write-Log "DÉBUT - Import utilisateurs [$OrgName]" -Level INFO
Write-Log "CSV         : $CSVFile"                 -Level INFO
Write-Log "Délimiteur  : '$Delimiter'"             -Level INFO
Write-Log "Mdp défaut  : $DefaultPassword"         -Level INFO
Write-Log "Groupes     : $AddToGroups"             -Level INFO
Write-Log "Ordinateurs : $ImportOrdinateurs"       -Level INFO
Write-Log "Externes    : $ImportExterne"           -Level INFO
if ($WhatIf) { Write-Log "MODE SIMULATION (WhatIf)" -Level WARNING }
Write-Log "========================================" -Level INFO
Write-Host ""

# Vérification CSV
if (-not (Test-Path $CSVFile)) {
    Write-Log "✗ Fichier CSV introuvable : $CSVFile" -Level ERROR; exit 1
}
try   { $AllRows = Import-Csv -Path $CSVFile -Delimiter $Delimiter -Encoding UTF8 }
catch { Write-Log "✗ Erreur lecture CSV : $($_.Exception.Message)" -Level ERROR; exit 1 }

$BillURows   = $AllRows | Where-Object { (Clean-Value $_.'Societe') -eq $SocietePrincipale }
$ExterneRows = $AllRows | Where-Object { (Clean-Value $_.'Societe') -ne $SocietePrincipale }
$ToImport    = if ($ImportExterne) { $AllRows } else { $BillURows }

Write-Log "Lignes CSV totales  : $($AllRows.Count)"    -Level INFO
Write-Log "  → Internes BillU  : $($BillURows.Count)"  -Level INFO
Write-Log "  → Externes        : $($ExterneRows.Count) $(if (-not $ImportExterne){'(ignorés)'})" -Level INFO
Write-Log "  → À importer      : $($ToImport.Count)"   -Level INFO
Write-Host ""

$Script:Created = 0; $Script:Errors = 0; $Script:Skipped = 0
$Script:AddedToGroups = 0; $Script:ComputersCreated = 0
$CreatedUsers = @()

# ============================================================================
# PHASE 1 : CRÉATION DES COMPTES UTILISATEURS
# ============================================================================

Write-Log "--- PHASE 1 : Création des comptes utilisateurs ---" -Level INFO
Write-Host ""

foreach ($Row in $ToImport) {
    $Result = New-ADUserFromCSV -Row $Row -WhatIfMode:$WhatIf
    if ($Result -is [hashtable]) { $CreatedUsers += [PSCustomObject]$Result; $Script:Created++ }
    elseif ($null -eq $Result)   { $Script:Skipped++ }
    else                         { $Script:Errors++  }
}

Write-Host ""
Write-Log "Phase 1 terminée — Créés : $Script:Created  |  Skippés : $Script:Skipped  |  Erreurs : $Script:Errors" -Level SUCCESS
Write-Host ""

# ============================================================================
# PHASE 2 : AFFECTATION AUX GROUPES DE DÉPARTEMENT
# ============================================================================
# Note : Le groupe est basé sur le DÉPARTEMENT (pas le service).
# Tous les membres d'un département partagent le même groupe GG_{Code}_Users,
# quel que soit leur service.

if ($AddToGroups -and -not $WhatIf) {
    Write-Log "--- PHASE 2 : Affectation aux groupes de département ---" -Level INFO
    Write-Host ""

    foreach ($User in $CreatedUsers) {
        $GroupName = $DeptGroupMap[$User.Departement]
        if (-not $GroupName) {
            Write-Log "  ⚠ Pas de groupe configuré pour : '$($User.Departement)'" -Level WARNING; continue
        }
        if (-not (Get-ADGroup -Filter "Name -eq '$GroupName'" -ErrorAction SilentlyContinue)) {
            Write-Log "  ⚠ Groupe introuvable : $GroupName (script 02 exécuté ?)" -Level WARNING; continue
        }
        try {
            Add-ADGroupMember -Identity $GroupName -Members $User.Login -ErrorAction Stop
            Write-Log "  ✓ $($User.Login) → $GroupName" -Level SUCCESS
            $Script:AddedToGroups++
        }
        catch { Write-Log "  ✗ $($User.Login) → $GroupName : $($_.Exception.Message)" -Level ERROR }
    }

    # Groupe universel "Tous les employés"
    Write-Host ""
    Write-Log "Ajout au groupe universel GG_ALL_Employees..." -Level INFO
    if (Get-ADGroup -Filter "Name -eq 'GG_ALL_Employees'" -ErrorAction SilentlyContinue) {
        foreach ($User in $CreatedUsers) {
            Add-ADGroupMember -Identity "GG_ALL_Employees" -Members $User.Login -ErrorAction SilentlyContinue
        }
        Write-Log "✓ $($CreatedUsers.Count) utilisateurs → GG_ALL_Employees" -Level SUCCESS
    }
    else { Write-Log "⚠ GG_ALL_Employees introuvable" -Level WARNING }

    Write-Host ""
    Write-Log "Phase 2 terminée — Ajouts aux groupes : $Script:AddedToGroups" -Level SUCCESS
    Write-Host ""
}

# ============================================================================
# PHASE 3 : CONFIGURATION DES MANAGERS
# ============================================================================

if (-not $WhatIf) {
    Write-Log "--- PHASE 3 : Configuration des managers ---" -Level INFO
    Write-Host ""

    $ManagersSet = 0

    foreach ($User in $CreatedUsers) {
        $MgrPrenom = $User.ManagerPrenom
        $MgrNom    = $User.ManagerNom
        if (-not $MgrPrenom -or -not $MgrNom) { continue }

        $ManagerLogin = "$(Remove-Accents $MgrPrenom).$(Remove-Accents $MgrNom)"
        $Manager = Get-ADUser -Filter "SamAccountName -eq '$ManagerLogin'" -ErrorAction SilentlyContinue

        if ($Manager) {
            try {
                Set-ADUser -Identity $User.Login -Manager $Manager.DistinguishedName -ErrorAction Stop
                Write-Log "  ✓ $($User.Login) → manager : $ManagerLogin" -Level SUCCESS
                $ManagersSet++
            }
            catch { Write-Log "  ✗ Manager pour $($User.Login) : $($_.Exception.Message)" -Level ERROR }
        }
        else { Write-Log "  ⚠ Manager introuvable : $ManagerLogin (pour $($User.Login))" -Level WARNING }
    }

    Write-Host ""
    Write-Log "Phase 3 terminée — Managers définis : $ManagersSet" -Level SUCCESS
    Write-Host ""
}

# ============================================================================
# PHASE 4 : ENREGISTREMENT DES ORDINATEURS DANS OU=Ordinateurs
# ============================================================================

if ($ImportOrdinateurs -and -not $WhatIf) {
    Write-Log "--- PHASE 4 : Enregistrement des ordinateurs ---" -Level INFO
    Write-Host ""

    $ComputerOU = "OU=$OuPCs,$DomainDN"

    if (-not (Get-ADOrganizationalUnit -Filter "DistinguishedName -eq '$ComputerOU'" -ErrorAction SilentlyContinue)) {
        Write-Log "  ✗ OU Ordinateurs introuvable : $ComputerOU" -Level ERROR
    }
    else {
        foreach ($User in $CreatedUsers) {
            $NomPC    = $User.NomPC
            $MarquePC = $User.MarquePC
            if (-not $NomPC) { continue }

            if (Get-ADComputer -Filter "Name -eq '$NomPC'" -ErrorAction SilentlyContinue) {
                Write-Log "  ⚠ Déjà enregistré : $NomPC" -Level WARNING; continue
            }

            try {
                $Desc = if ($MarquePC) {
                    "$MarquePC — $($User.DisplayName) ($($User.Departement)$(if($User.Service){" / $($User.Service)"}))"
                } else {
                    "$($User.DisplayName) ($($User.Departement))"
                }

                New-ADComputer -Name $NomPC -Path $ComputerOU -Description $Desc `
                    -ManagedBy $User.Login -Enabled $true -ErrorAction Stop

                Write-Log "  ✓ $NomPC ($MarquePC) → $($User.Login)" -Level SUCCESS
                $Script:ComputersCreated++
            }
            catch { Write-Log "  ✗ $NomPC : $($_.Exception.Message)" -Level ERROR }
        }
    }

    Write-Host ""
    Write-Log "Phase 4 terminée — Ordinateurs enregistrés : $Script:ComputersCreated" -Level SUCCESS
    Write-Host ""
}

# ============================================================================
# RÉCAPITULATIF FINAL
# ============================================================================

Write-Log "========================================" -Level INFO
Write-Log "RÉCAPITULATIF FINAL"                      -Level INFO
Write-Log "  Lignes traitées    : $($ToImport.Count)"        -Level INFO
Write-Log "  Comptes créés      : $Script:Created"            -Level SUCCESS
Write-Log "  Comptes skippés    : $Script:Skipped"            -Level WARNING
Write-Log "  Erreurs            : $Script:Errors"             -Level ERROR
if ($AddToGroups -and -not $WhatIf) {
    Write-Log "  Ajouts groupes     : $Script:AddedToGroups"  -Level INFO
}
if ($ImportOrdinateurs -and -not $WhatIf) {
    Write-Log "  Ordinateurs créés  : $Script:ComputersCreated" -Level INFO
}
Write-Log "========================================" -Level INFO
Write-Host ""

# -----------------------------------------------------------------------
# STATISTIQUES
# -----------------------------------------------------------------------

if (-not $WhatIf) {
    Write-Log "--- STATISTIQUES PAR DÉPARTEMENT ET SERVICE ---" -Level INFO
    Write-Host ""

    # Utilisateurs par département
    Get-ADUser -Filter * -SearchBase "OU=Utilisateurs,$DomainDN" -Properties Department |
        Group-Object Department |
        Select-Object @{Name='Département';Expression={$_.Name}}, @{Name='Nb';Expression={$_.Count}} |
        Sort-Object Nb -Descending |
        Format-Table -AutoSize

    # Utilisateurs par service (sous-OU)
    Write-Host "Utilisateurs par OU service :" -ForegroundColor Cyan
    foreach ($Dept in $Departements) {
        if ($Dept.Services.Count -eq 0) {
            $DeptOU = "OU=$($Dept.Name),OU=Utilisateurs,$DomainDN"
            $Count  = (Get-ADUser -Filter * -SearchBase $DeptOU -SearchScope OneLevel -EA SilentlyContinue).Count
            Write-Host "  $($Dept.Name) (direct) : $Count" -ForegroundColor White
        } else {
            foreach ($Svc in $Dept.Services) {
                $SvcOU = "OU=$Svc,OU=$($Dept.Name),OU=Utilisateurs,$DomainDN"
                $Count = (Get-ADUser -Filter * -SearchBase $SvcOU -EA SilentlyContinue).Count
                Write-Host "  $($Dept.Name) > $Svc : $Count" -ForegroundColor White
            }
        }
    }
    Write-Host ""

    # Membres des groupes de département
    Write-Host "Membres des groupes de département :" -ForegroundColor Cyan
    foreach ($Dept in $Departements) {
        $GName = "GG_$($Dept.GroupCode)_Users"
        if (Get-ADGroup -Filter "Name -eq '$GName'" -EA SilentlyContinue) {
            $Count = (Get-ADGroupMember -Identity $GName -EA SilentlyContinue).Count
            Write-Host "  $GName : $Count membres" -ForegroundColor White
        }
    }
    Write-Host ""

    # Exports CSV
    if ($Script:Created -gt 0) {
        $ExportPath = Join-Path $LogBaseDir "Users-Created-$(Get-Date -Format 'yyyyMMdd-HHmmss').csv"
        Get-ADUser -Filter * -SearchBase "OU=Utilisateurs,$DomainDN" `
            -Properties Department, Description, Title, EmailAddress, OfficePhone, MobilePhone, Manager |
            Select-Object @{Name='Login';Expression={$_.SamAccountName}},
                          @{Name='Nom complet';Expression={$_.Name}},
                          Department,
                          @{Name='Service';Expression={$_.Description}},
                          Title, EmailAddress, OfficePhone, MobilePhone,
                          @{Name='Manager';Expression={(Get-ADUser $_.Manager -EA SilentlyContinue).SamAccountName}},
                          DistinguishedName, Enabled |
            Export-Csv -Path $ExportPath -NoTypeInformation -Encoding UTF8
        Write-Log "Export utilisateurs : $ExportPath" -Level SUCCESS
    }

    if ($Script:ComputersCreated -gt 0) {
        $ExportPCPath = Join-Path $LogBaseDir "Computers-Created-$(Get-Date -Format 'yyyyMMdd-HHmmss').csv"
        Get-ADComputer -Filter * -SearchBase "OU=$OuPCs,$DomainDN" -Properties Description, ManagedBy |
            Select-Object Name, Description,
                          @{Name='ManagedBy';Expression={(Get-ADUser $_.ManagedBy -EA SilentlyContinue).SamAccountName}} |
            Export-Csv -Path $ExportPCPath -NoTypeInformation -Encoding UTF8
        Write-Log "Export ordinateurs  : $ExportPCPath" -Level SUCCESS
    }
    Write-Host ""
}

Write-Host "╔════════════════════════════════════════════════════════╗" -ForegroundColor Yellow
Write-Host "║  PROCHAINES ÉTAPES                                      ║" -ForegroundColor Yellow
Write-Host "╠════════════════════════════════════════════════════════╣" -ForegroundColor Yellow
Write-Host "║  1. Vérifier la création des comptes                    ║" -ForegroundColor White
Write-Host "║  2. Tester la connexion d'un utilisateur                ║" -ForegroundColor White
Write-Host "║  3. Configurer les GPO si nécessaire                    ║" -ForegroundColor White
Write-Host "║  4. Créer les partages réseau et définir les droits     ║" -ForegroundColor White
Write-Host "║  5. Jonction des postes au domaine                      ║" -ForegroundColor White
Write-Host "╚════════════════════════════════════════════════════════╝" -ForegroundColor Yellow
Write-Host ""

Write-Log "FIN - Import utilisateurs" -Level INFO
