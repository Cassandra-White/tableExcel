# ============================================================================
# Script : 01-Create-OU-Structure.ps1
# Description : Création générique de l'arborescence des OUs
# Prérequis : 00-Config.ps1 dans le même dossier
# ============================================================================

<#
.SYNOPSIS
    Crée toute l'arborescence des OUs à partir de 00-Config.ps1.

.DESCRIPTION
    Structure créée :
      OU=Utilisateurs
        OU=<Département>           (un par entrée dans $Departements)
          OU=<Service>             (un par service listé dans $Dept.Services)
      OU=Ordinateurs               (plate — tous les PCs, pas de sous-OUs)
      OU=Groupes
        OU=<SousOU>                (selon $GroupSubOUs)
      OU=<Extra>                   (selon $MainOUsExtra)

.PARAMETER LogFile
    Chemin du fichier de log. Par défaut : $LogBaseDir\OU-Creation.log

.EXAMPLE
    .\01-Create-OU-Structure.ps1
    .\01-Create-OU-Structure.ps1 -LogFile "D:\Logs\ou.log"
#>

[CmdletBinding()]
param(
    [string]$LogFile = ""
)

# ============================================================================
# CHARGEMENT DE LA CONFIGURATION
# ============================================================================

$ConfigFile = Join-Path -Path $PSScriptRoot -ChildPath "00-Config.ps1"
if (-not (Test-Path $ConfigFile)) {
    Write-Error "Fichier de configuration introuvable : $ConfigFile"
    exit 1
}
. $ConfigFile

if (-not $LogFile) { $LogFile = Join-Path $LogBaseDir "OU-Creation.log" }

# ============================================================================
# INITIALISATION
# ============================================================================

$LogDir = Split-Path -Path $LogFile -Parent
if (-not (Test-Path $LogDir)) { New-Item -Path $LogDir -ItemType Directory -Force | Out-Null }

try { Import-Module ActiveDirectory -ErrorAction Stop }
catch { Write-Error "Module ActiveDirectory non disponible. Installez RSAT."; exit 1 }

$DomainDN   = (Get-ADDomain).DistinguishedName
$DomainName = (Get-ADDomain).DNSRoot

# ============================================================================
# FONCTIONS
# ============================================================================

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','SUCCESS','WARNING','ERROR')]
        [string]$Level = 'INFO'
    )
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogFile -Value "[$Timestamp] [$Level] $Message"
    switch ($Level) {
        'SUCCESS' { Write-Host $Message -ForegroundColor Green  }
        'WARNING' { Write-Host $Message -ForegroundColor Yellow }
        'ERROR'   { Write-Host $Message -ForegroundColor Red    }
        default   { Write-Host $Message -ForegroundColor White  }
    }
}

function New-OU {
    param(
        [string]$Name,
        [string]$Path,
        [string]$Description = "",
        [string]$Indent = "  "
    )
    $Script:TotalOUs++
    $OUDN = "OU=$Name,$Path"
    try {
        if (Get-ADOrganizationalUnit -Filter "DistinguishedName -eq '$OUDN'" -ErrorAction SilentlyContinue) {
            Write-Log "${Indent}(existe) OU=$Name" -Level WARNING
            $Script:ExistingOUs++
            return
        }
        New-ADOrganizationalUnit -Name $Name -Path $Path -Description $Description `
            -ProtectedFromAccidentalDeletion $true | Out-Null
        Write-Log "${Indent}✓ OU=$Name" -Level SUCCESS
        $Script:CreatedOUs++
    }
    catch {
        Write-Log "${Indent}✗ OU=$Name : $($_.Exception.Message)" -Level ERROR
        $Script:ErrorOUs++
    }
}

# ============================================================================
# SCRIPT PRINCIPAL
# ============================================================================

$Script:TotalOUs = 0; $Script:CreatedOUs = 0; $Script:ExistingOUs = 0; $Script:ErrorOUs = 0

Write-Log "========================================" -Level INFO
Write-Log "DÉBUT - Création arborescence OU [$OrgName]" -Level INFO
Write-Log "Domaine : $DomainName  |  DN : $DomainDN"    -Level INFO
Write-Log "========================================" -Level INFO
Write-Host ""

# -----------------------------------------------------------------------
# ÉTAPE 1 : OUs PRINCIPALES
# -----------------------------------------------------------------------

Write-Log "--- ÉTAPE 1 : OUs Principales ---" -Level INFO

New-OU -Name "Utilisateurs" -Path $DomainDN -Description "Comptes utilisateurs de $OrgName"
New-OU -Name $OuPCs         -Path $DomainDN -Description "Ordinateurs de $OrgName (OU plate)"
New-OU -Name "Groupes"      -Path $DomainDN -Description "Groupes AD de $OrgName"

foreach ($OU in $MainOUsExtra) {
    New-OU -Name $OU.Name -Path $DomainDN -Description $OU.Description
}

Write-Host ""

# -----------------------------------------------------------------------
# ÉTAPE 2 : SOUS-OUs UTILISATEURS — DÉPARTEMENTS + SERVICES
# -----------------------------------------------------------------------

Write-Log "--- ÉTAPE 2 : Départements et Services ---" -Level INFO
Write-Host ""

$UtilisateursOU = "OU=Utilisateurs,$DomainDN"

foreach ($Dept in $Departements) {

    # OU département
    Write-Log "  [Département] $($Dept.Name)" -Level INFO
    New-OU -Name $Dept.Name -Path $UtilisateursOU -Description $Dept.Description -Indent "    "

    # Sous-OUs services (si définis)
    if ($Dept.Services -and $Dept.Services.Count -gt 0) {
        $DeptOU = "OU=$($Dept.Name),$UtilisateursOU"
        foreach ($Svc in $Dept.Services) {
            New-OU -Name $Svc -Path $DeptOU `
                   -Description "Service $Svc — $($Dept.Name)" `
                   -Indent "      "
        }
    }
    else {
        Write-Log "      (pas de sous-OU service — utilisateurs directement dans l'OU département)" -Level INFO
    }

    Write-Host ""
}

# -----------------------------------------------------------------------
# ÉTAPE 3 : ORDINATEURS — OU PLATE, PAS DE SOUS-OUs
# -----------------------------------------------------------------------

Write-Log "--- ÉTAPE 3 : OU Ordinateurs (flat) ---" -Level INFO
Write-Log "  ℹ  Tous les PCs dans : OU=$OuPCs,$DomainDN" -Level INFO
Write-Host ""

# -----------------------------------------------------------------------
# ÉTAPE 4 : SOUS-OUs GROUPES
# -----------------------------------------------------------------------

Write-Log "--- ÉTAPE 4 : Sous-OUs Groupes ---" -Level INFO

$GroupesOU = "OU=Groupes,$DomainDN"
foreach ($SubOU in $GroupSubOUs) {
    New-OU -Name $SubOU.Name -Path $GroupesOU -Description $SubOU.Description
}

Write-Host ""

# ============================================================================
# RÉCAPITULATIF
# ============================================================================

Write-Log "========================================" -Level INFO
Write-Log "RÉCAPITULATIF" -Level INFO
Write-Log "  OUs traitées      : $Script:TotalOUs"      -Level INFO
Write-Log "  Créées            : $Script:CreatedOUs"     -Level SUCCESS
Write-Log "  Déjà existantes   : $Script:ExistingOUs"    -Level WARNING
Write-Log "  Erreurs           : $Script:ErrorOUs"       -Level ERROR
Write-Log "========================================" -Level INFO
Write-Host ""

# Aperçu de l'arborescence
Write-Log "--- ARBORESCENCE CRÉÉE ---" -Level INFO
Write-Host ""
Get-ADOrganizationalUnit -Filter * |
    Select-Object @{Name='OU';Expression={$_.Name}}, DistinguishedName |
    Sort-Object DistinguishedName |
    Format-Table -AutoSize

# Export CSV
$ExportPath = Join-Path $LogBaseDir "OU-Structure-$(Get-Date -Format 'yyyyMMdd-HHmmss').csv"
Get-ADOrganizationalUnit -Filter * |
    Select-Object Name, DistinguishedName |
    Sort-Object DistinguishedName |
    Export-Csv -Path $ExportPath -NoTypeInformation -Encoding UTF8

Write-Log "Structure exportée : $ExportPath" -Level SUCCESS
Write-Log "FIN - Création arborescence OU" -Level INFO
