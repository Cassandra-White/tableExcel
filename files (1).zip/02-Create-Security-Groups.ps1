# ============================================================================
# Script : 02-Create-Security-Groups.ps1
# Description : Création générique des groupes de sécurité
# Prérequis : 00-Config.ps1 dans le même dossier + script 01 exécuté
# ============================================================================

<#
.SYNOPSIS
    Crée automatiquement tous les groupes AD à partir de 00-Config.ps1

.DESCRIPTION
    Groupes créés :
      1. GG_{GroupCode}_Users   → un par département (depuis $Departements)
      2. GG_{GroupCode}_Admins  → si HasAdminGroup=$true dans $Departements
      3. GD_{GroupCode}         → groupes de distribution (si HasDistribGroup=$true)
      4. Groupes fonctionnels   → depuis $GroupesFonctionnels
      5. Groupes partages       → depuis $PartagesConfig (GG_{DeptCode}_{Permission})

.PARAMETER LogFile
    Chemin du fichier de log. Par défaut : $LogBaseDir\Groups-Creation.log

.EXAMPLE
    .\02-Create-Security-Groups.ps1
    .\02-Create-Security-Groups.ps1 -LogFile "D:\Logs\groups.log"
#>

[CmdletBinding()]
param(
    [string]$LogFile = ""
)

# ============================================================================
# CHARGEMENT DE LA CONFIGURATION
# ============================================================================

$ConfigFile = Join-Path -Path $PSScriptRoot -ChildPath "00-Config.ps1"
if (-not (Test-Path $ConfigFile)) {
    Write-Error "Fichier de configuration introuvable : $ConfigFile"
    exit 1
}
. $ConfigFile

if (-not $LogFile) { $LogFile = Join-Path $LogBaseDir "Groups-Creation.log" }

# ============================================================================
# INITIALISATION
# ============================================================================

$LogDir = Split-Path -Path $LogFile -Parent
if (-not (Test-Path $LogDir)) { New-Item -Path $LogDir -ItemType Directory -Force | Out-Null }

try { Import-Module ActiveDirectory -ErrorAction Stop }
catch { Write-Error "Module ActiveDirectory non disponible. Installez RSAT."; exit 1 }

$DomainDN   = (Get-ADDomain).DistinguishedName
$DomainName = (Get-ADDomain).DNSRoot

# ============================================================================
# FONCTIONS
# ============================================================================

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','SUCCESS','WARNING','ERROR')]
        [string]$Level = 'INFO'
    )
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogFile -Value "[$Timestamp] [$Level] $Message"
    switch ($Level) {
        'SUCCESS' { Write-Host $Message -ForegroundColor Green  }
        'WARNING' { Write-Host $Message -ForegroundColor Yellow }
        'ERROR'   { Write-Host $Message -ForegroundColor Red    }
        default   { Write-Host $Message -ForegroundColor White  }
    }
}

function New-Group {
    param(
        [string]$Name,
        [string]$Path,
        [string]$Description,
        [ValidateSet('Global','Universal','DomainLocal')]
        [string]$Scope    = 'Global',
        [ValidateSet('Security','Distribution')]
        [string]$Category = 'Security'
    )
    $Script:TotalGroups++
    try {
        # Vérifier existence
        if (Get-ADGroup -Filter "Name -eq '$Name'" -ErrorAction SilentlyContinue) {
            Write-Log "  (existe) $Name" -Level WARNING
            $Script:ExistingGroups++
            return
        }
        # Vérifier OU cible
        if (-not (Get-ADOrganizationalUnit -Filter "DistinguishedName -eq '$Path'" -ErrorAction SilentlyContinue)) {
            Write-Log "  ✗ OU introuvable pour $Name : $Path" -Level ERROR
            $Script:ErrorGroups++
            return
        }
        New-ADGroup -Name $Name -Path $Path -GroupScope $Scope -GroupCategory $Category `
            -Description $Description | Out-Null
        Write-Log "  ✓ $Name  [$Scope / $Category]" -Level SUCCESS
        $Script:CreatedGroups++
    }
    catch {
        Write-Log "  ✗ $Name : $($_.Exception.Message)" -Level ERROR
        $Script:ErrorGroups++
    }
}

# ============================================================================
# SCRIPT PRINCIPAL
# ============================================================================

$Script:TotalGroups = 0; $Script:CreatedGroups = 0
$Script:ExistingGroups = 0; $Script:ErrorGroups = 0

Write-Log "========================================" -Level INFO
Write-Log "DÉBUT - Création groupes AD [$OrgName]"  -Level INFO
Write-Log "Domaine : $DomainName"                    -Level INFO
Write-Log "========================================" -Level INFO
Write-Host ""

# OUs de destination (issues de la config)
$OU_Depts  = "OU=Groupes-Departements,OU=Groupes,$DomainDN"
$OU_Fonct  = "OU=Groupes-Fonctionnels,OU=Groupes,$DomainDN"
$OU_Secu   = "OU=Groupes-Securite,OU=Groupes,$DomainDN"

# -----------------------------------------------------------------------
# ÉTAPE 1 : GROUPES DE DÉPARTEMENTS (générés depuis $Departements)
# -----------------------------------------------------------------------

Write-Log "--- ÉTAPE 1 : Groupes de Départements ---" -Level INFO

foreach ($Dept in $Departements) {
    # Groupe principal : tous les utilisateurs du département
    New-Group -Name "GG_$($Dept.GroupCode)_Users" `
              -Path $OU_Depts `
              -Description "Tous les utilisateurs du département $($Dept.Name)"

    # Groupe administrateurs (optionnel)
    if ($Dept.HasAdminGroup) {
        New-Group -Name "GG_$($Dept.GroupCode)_Admins" `
                  -Path $OU_Depts `
                  -Description "Administrateurs du département $($Dept.Name)"
    }
}

Write-Host ""

# -----------------------------------------------------------------------
# ÉTAPE 2 : GROUPES FONCTIONNELS (depuis $GroupesFonctionnels)
# -----------------------------------------------------------------------

Write-Log "--- ÉTAPE 2 : Groupes Fonctionnels ---" -Level INFO

foreach ($Group in $GroupesFonctionnels) {
    New-Group -Name     $Group.Name `
              -Path     $OU_Fonct `
              -Description $Group.Description `
              -Scope    $Group.Scope `
              -Category $Group.Category
}

Write-Host ""

# -----------------------------------------------------------------------
# ÉTAPE 3 : GROUPES DE DISTRIBUTION (générés depuis $Departements)
# -----------------------------------------------------------------------

Write-Log "--- ÉTAPE 3 : Groupes de Distribution ---" -Level INFO

# Groupe universel "Tous les employés" (toujours créé)
New-Group -Name "GD_ALL_Staff" -Path $OU_Fonct `
          -Description "Liste de distribution - Tous les employés de $OrgName" `
          -Scope "Universal" -Category "Distribution"

foreach ($Dept in $Departements | Where-Object { $_.HasDistribGroup }) {
    New-Group -Name "GD_$($Dept.GroupCode)" `
              -Path $OU_Fonct `
              -Description "Liste de distribution - $($Dept.Name)" `
              -Scope "Global" -Category "Distribution"
}

Write-Host ""

# -----------------------------------------------------------------------
# ÉTAPE 4 : GROUPES PARTAGES RÉSEAU (depuis $PartagesConfig)
# -----------------------------------------------------------------------

Write-Log "--- ÉTAPE 4 : Groupes de Sécurité (Partages Réseau) ---" -Level INFO

$PermDescriptions = @{
    "RO"   = "Lecture seule"
    "RW"   = "Lecture/Écriture"
    "FULL" = "Contrôle total"
}

foreach ($Partage in $PartagesConfig) {
    foreach ($Perm in $Partage.Permissions) {
        $Desc = "$($PermDescriptions[$Perm]) sur le partage $($Partage.DeptCode)"
        New-Group -Name "GG_$($Partage.DeptCode)_$Perm" `
                  -Path $OU_Secu `
                  -Description $Desc
    }
}

Write-Host ""

# ============================================================================
# RÉCAPITULATIF
# ============================================================================

Write-Log "========================================" -Level INFO
Write-Log "RÉCAPITULATIF" -Level INFO
Write-Log "  Groupes traités    : $Script:TotalGroups"   -Level INFO
Write-Log "  Créés              : $Script:CreatedGroups" -Level SUCCESS
Write-Log "  Déjà existants     : $Script:ExistingGroups" -Level WARNING
Write-Log "  Erreurs            : $Script:ErrorGroups"   -Level ERROR
Write-Log "========================================" -Level INFO
Write-Host ""

# Statistiques par OU
Write-Host "Groupes par OU :" -ForegroundColor Cyan
Get-ADGroup -Filter * -SearchBase "OU=Groupes,$DomainDN" |
    Group-Object { $_.DistinguishedName -replace '^CN=[^,]+,','' } |
    Select-Object @{Name='OU';Expression={$_.Name}}, Count |
    Sort-Object Count -Descending |
    Format-Table -AutoSize

# Export CSV
$ExportPath = Join-Path $LogBaseDir "Security-Groups-$(Get-Date -Format 'yyyyMMdd-HHmmss').csv"
Get-ADGroup -Filter * -SearchBase "OU=Groupes,$DomainDN" -Properties Description |
    Select-Object Name, GroupScope, GroupCategory, Description, DistinguishedName |
    Export-Csv -Path $ExportPath -NoTypeInformation -Encoding UTF8

Write-Log "Groupes exportés : $ExportPath" -Level SUCCESS

Write-Host ""
Write-Host "╔════════════════════════════════════════════════════════╗" -ForegroundColor Yellow
Write-Host "║  PROCHAINES ÉTAPES                                      ║" -ForegroundColor Yellow
Write-Host "╠════════════════════════════════════════════════════════╣" -ForegroundColor Yellow
Write-Host "║  1. Importer les utilisateurs (script 03)               ║" -ForegroundColor White
Write-Host "║  2. Affecter les utilisateurs aux groupes département   ║" -ForegroundColor White
Write-Host "║  3. Configurer les partages réseau et permissions       ║" -ForegroundColor White
Write-Host "╚════════════════════════════════════════════════════════╝" -ForegroundColor Yellow
Write-Host ""

Write-Log "FIN - Création groupes AD" -Level INFO
