#Requires -RunAsAdministrator
# 03-Create-UserHomeFolders.ps1 -- BillU Sprint 5
# Cree D:\Partages\Homes\[login] pour chaque user actif
# Permission : Admins (BUILTIN\Administrators + SYSTEM + Domain Admins) = FullControl
#              Utilisateur proprietaire = FullControl

. ".\00-Config.ps1"
$DomInfo   = Get-ADDomain -Credential $ADCredential
$NB        = $DomInfo.NetBIOSName
$SiteDN    = "OU=$SiteOU,OU=$CountryOU,OU=$RootOU,$($DomInfo.DistinguishedName)"
$HomesRoot = "D:\Partages\Homes"
$Created   = 0

$inh  = [System.Security.AccessControl.InheritanceFlags]"ContainerInherit,ObjectInherit"
$prop = [System.Security.AccessControl.PropagationFlags]::None
$alw  = [System.Security.AccessControl.AccessControlType]::Allow
$full = [System.Security.AccessControl.FileSystemRights]::FullControl

$users = Get-ADUser -Filter {Enabled -eq $true} `
    -SearchBase "OU=Utilisateurs,$SiteDN" -SearchScope Subtree `
    -Credential $ADCredential

foreach ($u in $users) {
    $dir = "$HomesRoot\$($u.SamAccountName)"
    if (Test-Path $dir) { continue }

    New-Item $dir -ItemType Directory -Force | Out-Null

    $acl = New-Object System.Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)

    # Admins : FullControl (3 entrees)
    foreach ($id in @("BUILTIN\Administrators","NT AUTHORITY\SYSTEM","$NB\Domain Admins")) {
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule(
            $id, $full, $inh, $prop, $alw)))
    }

    # Proprietaire : FullControl sur son dossier uniquement
    $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule(
        "$NB\$($u.SamAccountName)", $full, $inh, $prop, $alw)))

    Set-Acl $dir $acl
    Write-Host "[OK] $dir"
    $Created++
}
Write-Host "=== $Created dossiers homes crees ==="
