# 04-Assign-ServiceGroups.ps1 -- BillU Sprint 5
# Affecte chaque user a son groupe GG_SVC_[service]
# Lit la Description AD du user = CSVName du service (renseignee par 03-Import-Users.ps1)

. ".\00-Config.ps1"
$DomInfo = Get-ADDomain -Credential $ADCredential
$SiteDN  = "OU=$SiteOU,OU=$CountryOU,OU=$RootOU,$($DomInfo.DistinguishedName)"

# Index CSVName -> OUName depuis $Departements (00-Config.ps1)
$SvcIdx = @{}
foreach ($D in $Departements) {
    foreach ($S in $D.Services) {
        $SvcIdx[$S.CSVName.ToLower().Trim()] = $S.OUName
    }
}

$users = Get-ADUser -Filter {Enabled -eq $true} `
    -SearchBase "OU=Utilisateurs,$SiteDN" -SearchScope Subtree `
    -Properties Description -Credential $ADCredential

$Added = 0; $Skip = 0; $Err = 0
foreach ($u in $users) {
    $key = $u.Description?.ToLower().Trim()
    if (-not $key -or -not $SvcIdx.ContainsKey($key)) { $Skip++; continue }
    $grp = "GG_SVC_$($SvcIdx[$key])"
    try {
        Add-ADGroupMember -Identity $grp -Members $u.SamAccountName `
            -Credential $ADCredential -ErrorAction Stop
        $Added++
    } catch { $Err++ }
}
Write-Host "=== $Added affectations | $Skip sans service | $Err erreurs ==="
