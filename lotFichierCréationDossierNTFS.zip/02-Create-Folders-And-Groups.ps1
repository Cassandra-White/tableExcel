#Requires -RunAsAdministrator
# 02-Create-Folders-And-Groups.ps1 -- BillU Sprint 5
# Cree l arborescence D:\Partages, les groupes GG_SVC_* et les ACL NTFS
# Admins toujours FullControl : BUILTIN\Administrators + SYSTEM + Domain Admins

. ".\00-Config.ps1"

$DomInfo = Get-ADDomain -Credential $ADCredential
$DN      = $DomInfo.DistinguishedName
$SiteDN  = "OU=$SiteOU,OU=$CountryOU,OU=$RootOU,$DN"
$OuSecu  = "OU=Groupes-Securite,OU=Groupes,$SiteDN"
$Base    = "D:\Partages"
$NB      = $DomInfo.NetBIOSName   # BILLU

# ======================================================
# Helper : construit une ACL avec les 3 comptes admins
# + des regles supplementaires optionnelles
# ======================================================
function Get-AdminACL {
    param([System.Security.AccessControl.FileSystemAccessRule[]]$Extra = @())

    $acl = New-Object System.Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)   # couper heritage

    $inh  = [System.Security.AccessControl.InheritanceFlags]"ContainerInherit,ObjectInherit"
    $prop = [System.Security.AccessControl.PropagationFlags]::None
    $alw  = [System.Security.AccessControl.AccessControlType]::Allow
    $full = [System.Security.AccessControl.FileSystemRights]::FullControl

    # --- Trois entrees admin obligatoires ---
    foreach ($id in @(
        "BUILTIN\Administrators",    # groupe Administrateurs (inclut Domain Admins)
        "NT AUTHORITY\SYSTEM",       # compte systeme (taches planifiees, services)
        "$NB\Domain Admins"          # admins domaine (entree explicite de securite)
    )) {
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule(
            $id, $full, $inh, $prop, $alw)))
    }

    foreach ($r in $Extra) { $acl.AddAccessRule($r) }
    return $acl
}

$inh  = [System.Security.AccessControl.InheritanceFlags]"ContainerInherit,ObjectInherit"
$prop = [System.Security.AccessControl.PropagationFlags]::None
$alw  = [System.Security.AccessControl.AccessControlType]::Allow
$mod  = [System.Security.AccessControl.FileSystemRights]::Modify

# ---- 1. Arborescence racine ----
foreach ($d in @("$Base\Homes","$Base\Services","$Base\Departements")) {
    New-Item $d -ItemType Directory -Force | Out-Null
}
# Racines accessibles admins seulement
foreach ($d in @("$Base\Homes","$Base\Services","$Base\Departements")) {
    Set-Acl $d (Get-AdminACL)
}

# ---- 2. Dossiers de service J: ----
Write-Host "=== Groupes et dossiers de service ==="
foreach ($Dept in $Departements) {
    foreach ($Svc in $Dept.Services) {
        $grp = "GG_SVC_$($Svc.OUName)"
        $dir = "$Base\Services\$($Svc.OUName)"

        if (-not (Get-ADGroup -Filter "Name -eq '$grp'" -Credential $ADCredential -EA SilentlyContinue)) {
            New-ADGroup -Name $grp -GroupScope Global -GroupCategory Security `
                -Path $OuSecu -Description "Acces J: $($Svc.OUName)" -Credential $ADCredential
            Write-Host "  [NEW] $grp"
        } else { Write-Host "  [OK] $grp" }

        New-Item $dir -ItemType Directory -Force | Out-Null
        $r = New-Object System.Security.AccessControl.FileSystemAccessRule("$NB\$grp",$mod,$inh,$prop,$alw)
        Set-Acl $dir (Get-AdminACL -Extra @($r))
    }
}

# ---- 3. Dossiers departement K: ----
Write-Host "=== Dossiers de departement ==="
$deptMap = @{
    "Direction"    = "GG_DIRECTION_Users"; "Dev-Logiciel" = "GG_DEV_Users"
    "DSI"          = "GG_DSI_Users";       "Commercial"   = "GG_COMMERCIAL_Users"
    "Communication"= "GG_COMM_Users";      "Juridique"    = "GG_JURIDIQUE_Users"
    "Finance"      = "GG_FINANCE_Users";   "QHSE"         = "GG_QHSE_Users"
    "Recrutement"  = "GG_RH_Users"
}
foreach ($dept in $deptMap.Keys) {
    $dir = "$Base\Departements\$dept"
    New-Item $dir -ItemType Directory -Force | Out-Null
    $r = New-Object System.Security.AccessControl.FileSystemAccessRule("$NB\$($deptMap[$dept])",$mod,$inh,$prop,$alw)
    Set-Acl $dir (Get-AdminACL -Extra @($r))
    Write-Host "  [OK] $dept -> $($deptMap[$dept])"
}

Write-Host ""
Write-Host "=== Termine -- $Base ==="
Get-ChildItem $Base -Recurse -Directory | Select-Object FullName | Format-Table
