#Requires -RunAsAdministrator
# 05-Create-Shares.ps1 -- BillU Sprint 5
# Cree les 3 partages SMB sur DC1
# Permissions SMB larges (Authenticated Users) -- le filtrage fin est fait par les ACL NTFS
# GG_DSI_Admins + Domain Admins + Administrateurs = FullAccess sur les 3 partages

. ".\00-Config.ps1"
$DomInfo = Get-ADDomain -Credential $ADCredential
$NB      = $DomInfo.NetBIOSName

$fullAccess = @(
    "BUILTIN\Administrators",
    "NT AUTHORITY\SYSTEM",
    "$NB\Domain Admins",
    "$NB\GG_DSI_Admins"
)

$shares = @(
    @{ Name = "Homes";        Path = "D:\Partages\Homes";        Desc = "Dossiers individuels I:" },
    @{ Name = "Services";     Path = "D:\Partages\Services";     Desc = "Dossiers de service J:"  },
    @{ Name = "Departements"; Path = "D:\Partages\Departements"; Desc = "Dossiers de dept K:"     }
)

foreach ($s in $shares) {
    Remove-SmbShare -Name $s.Name -Force -ErrorAction SilentlyContinue

    New-SmbShare -Name $s.Name -Path $s.Path -Description $s.Desc `
        -FullAccess    $fullAccess `
        -ChangeAccess  "Authenticated Users" `
        -FolderEnumerationMode AccessBased | Out-Null

    Write-Host "[OK] \\DC1\$($s.Name)  ->  $($s.Path)"
}

Write-Host ""
Write-Host "=== Partages actifs ==="
Get-SmbShare | Where-Object { $_.Name -in @("Homes","Services","Departements") } |
    Format-Table Name, Path, Description

Write-Host ""
Write-Host "=== Acces SMB sur le partage Homes ==="
Get-SmbShareAccess -Name "Homes" | Format-Table AccountName, AccessControlType, AccessRight
