# ============================================================================
# Script      : 01-Create-OU-Structure.ps1
# Description : Creation de l'arborescence des OUs
# Prerequis   : 00-Config.ps1 dans le meme dossier
# ============================================================================

<#
.SYNOPSIS
    Cree toute l'arborescence des OUs avec le compte $ADAdminUser.

.DESCRIPTION
    Structure creee :
      DC=billu,DC=local
      └── OU=BillU
          └── OU=France
              └── OU=Paris
                  ├── OU=Utilisateurs
                  │   ├── OU=<Dept>
                  │   │   └── OU=<Svc>
                  ├── OU=Ordinateurs
                  ├── OU=Groupes
                  │   ├── OU=Groupes-Departements
                  │   ├── OU=Groupes-Fonctionnels
                  │   └── OU=Groupes-Securite
                  ├── OU=Comptes-Admin
                  └── OU=Comptes-Service

    Toutes les operations AD utilisent $ADCredential (defini dans 00-Config.ps1).
    Le compte administrateur est defini proprietaire de chaque OU creee.

.PARAMETER LogFile
    Chemin du fichier de log (defaut : $LogBaseDir\OU-Creation.log)

.PARAMETER WhatIf
    Mode simulation - aucune OU creee

.EXAMPLE
    .\01-Create-OU-Structure.ps1
    .\01-Create-OU-Structure.ps1 -WhatIf
#>

[CmdletBinding()]
param(
    [string]$LogFile = "",
    [switch]$WhatIf
)

# ============================================================================
# CHARGEMENT CONFIG
# ============================================================================

$ConfigFile = Join-Path $PSScriptRoot "00-Config.ps1"
if (-not (Test-Path $ConfigFile)) { Write-Error "00-Config.ps1 introuvable : $ConfigFile"; exit 1 }
. $ConfigFile

if (-not $LogFile) { $LogFile = Join-Path $LogBaseDir "OU-Creation.log" }

# ============================================================================
# INITIALISATION
# ============================================================================

$LogDir = Split-Path $LogFile -Parent
if (-not (Test-Path $LogDir)) { New-Item -Path $LogDir -ItemType Directory -Force | Out-Null }

try { Import-Module ActiveDirectory -ErrorAction Stop }
catch { Write-Error "Module ActiveDirectory non disponible. Installez RSAT."; exit 1 }

# Verification du compte admin
try {
    $DomainInfo = Get-ADDomain -Credential $ADCredential -ErrorAction Stop
}
catch {
    Write-Error "Echec d'authentification avec $ADAdminUser : $($_.Exception.Message)"
    exit 1
}

$DomainDN   = $DomainInfo.DistinguishedName
$DomainName = $DomainInfo.DNSRoot

# DNs de la hierarchie geographique
$RootDN    = "OU=$RootOU,$DomainDN"
$CountryDN = "OU=$CountryOU,$RootDN"
$SiteDN    = "OU=$SiteOU,$CountryDN"

$Script:TotalOUs = 0; $Script:CreatedOUs = 0
$Script:ExistOUs = 0; $Script:ErrorOUs   = 0

# ============================================================================
# FONCTIONS
# ============================================================================

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','SUCCESS','WARNING','ERROR')]
        [string]$Level = 'INFO'
    )
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogFile -Value "[$ts] [$Level] $Message"
    switch ($Level) {
        'SUCCESS' { Write-Host $Message -ForegroundColor Green  }
        'WARNING' { Write-Host $Message -ForegroundColor Yellow }
        'ERROR'   { Write-Host $Message -ForegroundColor Red    }
        default   { Write-Host $Message -ForegroundColor White  }
    }
}

function New-OU {
    param(
        [string]$OUName,
        [string]$Path,
        [string]$Description = "",
        [string]$Indent = "  "
    )
    $Script:TotalOUs++
    $OUDN = "OU=$OUName,$Path"

    try {
        if (Get-ADOrganizationalUnit -Filter "DistinguishedName -eq '$OUDN'" `
                -Credential $ADCredential -ErrorAction SilentlyContinue) {
            Write-Log "${Indent}(existe)  OU=$OUName" -Level WARNING
            $Script:ExistOUs++; return
        }
        if ($WhatIf) {
            Write-Log "${Indent}[SIM] OU=$OUName  dans  $Path" -Level INFO
            $Script:CreatedOUs++; return
        }

        # Creation avec le compte admin comme proprietaire
        New-ADOrganizationalUnit -Name $OUName -Path $Path -Description $Description `
            -ProtectedFromAccidentalDeletion $false `
            -Credential $ADCredential -ErrorAction Stop | Out-Null

        # Delegation du controle total au compte admin sur cette OU
        $OU = Get-ADOrganizationalUnit -Filter "DistinguishedName -eq '$OUDN'" `
                -Credential $ADCredential
        $AdminAccount = Get-ADUser -Identity ($ADAdminUser -replace '^.*\\','') `
                -Credential $ADCredential -ErrorAction SilentlyContinue
        if ($AdminAccount) {
            $ACL = Get-Acl -Path "AD:$OUDN"
            $AdminSID = [System.Security.Principal.SecurityIdentifier]$AdminAccount.SID
            $AllRights = [System.DirectoryServices.ActiveDirectoryRights]::GenericAll
            $Allow     = [System.Security.AccessControl.AccessControlType]::Allow
            $Inherit   = [System.DirectoryServices.ActiveDirectorySecurityInheritance]::All
            $Rule = New-Object System.DirectoryServices.ActiveDirectoryAccessRule(
                $AdminSID, $AllRights, $Allow, $Inherit
            )
            $ACL.AddAccessRule($Rule)
            Set-Acl -Path "AD:$OUDN" -AclObject $ACL -ErrorAction SilentlyContinue
        }

        Write-Log "${Indent}+ OU=$OUName" -Level SUCCESS
        $Script:CreatedOUs++
    }
    catch {
        Write-Log "${Indent}ERREUR OU=$OUName : $($_.Exception.Message)" -Level ERROR
        $Script:ErrorOUs++
    }
}

# ============================================================================
# SCRIPT PRINCIPAL
# ============================================================================

Write-Log "========================================" -Level INFO
Write-Log "DEBUT - Creation OUs [$OrgName]"         -Level INFO
Write-Log "Compte  : $ADAdminUser"                  -Level INFO
Write-Log "Domaine : $DomainName"                   -Level INFO
Write-Log "Site    : $SiteDN"                       -Level INFO
if ($WhatIf) { Write-Log "!!! MODE SIMULATION !!!" -Level WARNING }
Write-Log "========================================" -Level INFO
Write-Host ""

# -----------------------------------------------------------------------
# ETAPE 1 : HIERARCHIE GEOGRAPHIQUE
# -----------------------------------------------------------------------

Write-Log "--- Hierarchie geographique ---" -Level INFO
New-OU -OUName $RootOU    -Path $DomainDN  -Description "Organisation $OrgName"  -Indent ""
New-OU -OUName $CountryOU -Path $RootDN    -Description "Pays : $CountryOU"       -Indent "  "
New-OU -OUName $SiteOU    -Path $CountryDN -Description "Site : $SiteOU"          -Indent "    "
Write-Host ""

# -----------------------------------------------------------------------
# ETAPE 2 : OUs PRINCIPALES (dans OU=Paris)
# -----------------------------------------------------------------------

Write-Log "--- OUs principales dans OU=$SiteOU ---" -Level INFO
New-OU -OUName "Utilisateurs" -Path $SiteDN -Description "Comptes utilisateurs $OrgName - $SiteOU"
New-OU -OUName $OuPCs         -Path $SiteDN -Description "Ordinateurs $OrgName - $SiteOU (OU plate)"
New-OU -OUName "Groupes"      -Path $SiteDN -Description "Groupes AD $OrgName - $SiteOU"

foreach ($OU in $MainOUsExtra) {
    New-OU -OUName $OU.OUName -Path $SiteDN -Description $OU.Description
}
Write-Host ""

# -----------------------------------------------------------------------
# ETAPE 3 : DEPARTEMENTS ET SERVICES
# -----------------------------------------------------------------------

Write-Log "--- Departements et Services ---" -Level INFO
Write-Host ""

$UtilOU = "OU=Utilisateurs,$SiteDN"

foreach ($Dept in $Departements) {
    Write-Log "  [Dept] $($Dept.OUName)  (CSV : $($Dept.CSVName))" -Level INFO
    New-OU -OUName $Dept.OUName -Path $UtilOU -Description $Dept.Description -Indent "    "

    if ($Dept.Services.Count -gt 0) {
        $DeptOU = "OU=$($Dept.OUName),$UtilOU"
        foreach ($Svc in $Dept.Services) {
            New-OU -OUName $Svc.OUName -Path $DeptOU `
                   -Description "Service $($Svc.OUName) - $($Dept.OUName)" `
                   -Indent "      "
        }
    }
    else { Write-Log "      (pas de sous-OU service)" -Level INFO }
    Write-Host ""
}

# -----------------------------------------------------------------------
# ETAPE 4 : SOUS-OUs GROUPES
# -----------------------------------------------------------------------

Write-Log "--- Sous-OUs Groupes ---" -Level INFO
$GrpOU = "OU=Groupes,$SiteDN"
foreach ($SubOU in $GroupSubOUs) {
    New-OU -OUName $SubOU.OUName -Path $GrpOU -Description $SubOU.Description
}
Write-Host ""

# ============================================================================
# RECAPITULATIF
# ============================================================================

Write-Log "========================================" -Level INFO
Write-Log "RECAPITULATIF"                            -Level INFO
Write-Log "  Total traite  : $Script:TotalOUs"       -Level INFO
Write-Log "  Crees         : $Script:CreatedOUs"     -Level SUCCESS
Write-Log "  Existants     : $Script:ExistOUs"       -Level WARNING
Write-Log "  Erreurs       : $Script:ErrorOUs"       -Level ERROR
Write-Log "========================================" -Level INFO
Write-Host ""

if (-not $WhatIf) {
    $ExportPath = Join-Path $LogBaseDir "OU-Structure-$(Get-Date -Format 'yyyyMMdd-HHmmss').csv"
    Get-ADOrganizationalUnit -Filter * -SearchBase $RootDN -Credential $ADCredential |
        Select-Object Name, DistinguishedName |
        Sort-Object DistinguishedName |
        Export-Csv -Path $ExportPath -NoTypeInformation -Encoding UTF8
    Write-Log "Export structure : $ExportPath" -Level SUCCESS
}

Write-Log "FIN - Creation OUs" -Level INFO
